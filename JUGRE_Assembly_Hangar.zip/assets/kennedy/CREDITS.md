# Kennedy Space Center scene

Terrain imagery from the [USGS National Map Imagery Only basemap](https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer), accessed November 8, 2026. Source rasters were resampled, colour-blended at tile boundaries and extended over areas of missing offshore imagery. The reconstructed buildings are game models.

- [NASA overview map and photo tour](https://public.ksc.nasa.gov/socs/wp-content/uploads/sites/31/2024/07/SOCS-Contract-Presolicitation-Conference-Photo-Tour-Presentation.pdf)
- [NASA history of Launch Complex 39](https://www.nasa.gov/wp-content/uploads/static/history/SP-350/ch-6-1.html)
- [NASA Vehicle Assembly Building dimensions](https://asd.gsfc.nasa.gov/archive/sm3a/press-site.html)
- [NASA Launch Pad 39B](https://www.nasa.gov/humans-in-space/exploration-ground-systems/launch-pad-39b/)
- [NASA Shuttle Landing Facility](https://www.nasa.gov/kennedy/partnerships/shuttlelandingfacility/)
