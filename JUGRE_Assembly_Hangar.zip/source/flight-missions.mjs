import { MathUtils, Vector3 } from 'three';
import { reentryProfile } from './reentry-profile.mjs';
import { approachOrbit, departureSweep, orbitArc, tangentAlong, transferRoute } from './mission-paths.mjs';
import { FlightSystems } from './flight-systems.mjs';
import {
  DART_AFTERMATH_TIME, DART_APPROACH_RANGE, DART_APPROACH_TIME, DART_NOMINAL_ORIGIN,
  DART_RELEASE_RANGE, DART_SPEED, DART_TARGET, dartHeading, dartRange, dartWorldPosition, isDartEncounter,
} from './dart-course.mjs';

export const PREIGNITION_SECONDS = 2.4;

export const EARTH_RADIUS = 6371;
export const MOON_RADIUS = 1737.4;
export const FLORIDA = { lat: 28.6084, lon: -80.6042 };
export function geoVector(lat, lon, radius = 1) {
  const a = MathUtils.degToRad(lat);
  const b = MathUtils.degToRad(lon);
  return new Vector3(Math.cos(a) * Math.cos(b), Math.sin(a), -Math.cos(a) * Math.sin(b)).multiplyScalar(radius);
}
export const launchUp = geoVector(FLORIDA.lat, FLORIDA.lon);
export const east = new Vector3(-Math.sin(MathUtils.degToRad(FLORIDA.lon)), 0, -Math.cos(MathUtils.degToRad(FLORIDA.lon)));
export const MOON = new Vector3(0.64, 0.18, 0.747).normalize().multiplyScalar(384400);
export const moonUp = MOON.clone().normalize().negate();
const moonEast = tangentAlong(moonUp, east);
export const MARS = new Vector3(0.84, 0.13, -0.527).normalize().multiplyScalar(850000);
const marsSites = { mars_2020: geoVector(18.44, 77.45), mars_science_laboratory: geoVector(-4.59, 137.44) };
export const JUPITER = new Vector3(-0.48, 0.11, -0.87).normalize().multiplyScalar(1600000);
export const SATURN = new Vector3(-0.83, 0.18, -0.52).normalize().multiplyScalar(2600000);
export const ASTEROID = DART_TARGET;

const earthCenter = new Vector3();
const entryUp = geoVector(27.4, -77.4);
const recoveryUp = geoVector(27.4, -72.1);
const entryHeading = tangentAlong(entryUp, recoveryUp);
const entryArc = entryUp.angleTo(recoveryUp);
const transferTargets = {
  moonTransfer: { center: MOON, radius: MOON_RADIUS + 120, speed: [10.8, 1.1, 2.4] },
  marsTransfer: { center: MARS, radius: 4189.5, speed: [11.6, 24, 5.5] },
  jupiterTransfer: { center: JUPITER, radius: 110000, speed: [12.4, 13, 25] },
  saturnTransfer: { center: SATURN, radius: 105000, speed: [25, 15, 19] },
};
const minimumScreenTime = {
  ascent: 7, orbit: 2.4, moonOrbit: 1.8, lunarFlyby: 2.2, separate: 3.4, moonLanding: 4.0,
  moonSurface: 2, rendezvous: 5.8, reentry: 8.4, marsLanding: 6.0, marsSurface: 2,
  dartRelease: 6, stationApproach: 2.4, docking: 2.4, jupiterFlyby: 2.2, saturnFlyby: 2.2,
};
const phase = (label, kind, duration) => ({ label, kind, duration });
export const missions = {
  apollo_11: {
    title: '01 · Apollo 11', destination: 'Луна · Море Спокойствия', payload: 'apollo_docked', capsule: 'columbia', crew: true,
    phases: [
      phase('Старт из Флориды', 'ascent', 52),
      phase('Орбита Земли', 'orbit', 16),
      phase('Перелёт к Луне', 'moonTransfer', 128),
      phase('Лунная орбита', 'moonOrbit', 18),
      phase('Отделение Eagle', 'separate', 7),
      phase('Посадка в Море Спокойствия', 'moonLanding', 24),
      phase('Работа на поверхности', 'moonSurface', 14),
      phase('Взлёт и встреча с Columbia', 'rendezvous', 22),
      phase('Возвращение к Земле', 'earthReturn', 118),
      phase('Спуск и приводнение', 'reentry', 32),
    ],
  },
  artemis_ii: {
    title: '02 · Artemis II', destination: 'Облёт Луны → Земля', payload: 'orion', capsule: 'orion', crew: true,
    phases: [
      phase('Старт из Флориды', 'ascent', 52),
      phase('Орбита Земли', 'orbit', 16),
      phase('Перелёт к Луне', 'moonTransfer', 128),
      phase('Облёт обратной стороны Луны', 'lunarFlyby', 26),
      phase('Возвращение к Земле', 'earthReturn', 118),
      phase('Спуск и приводнение', 'reentry', 32),
    ],
  },
  mars_2020: {
    title: '03 · Mars 2020', destination: 'Марс · Perseverance и Ingenuity', payload: 'mars2020_ship', rover: 'perseverance',
    phases: [
      phase('Старт из Флориды', 'ascent', 52), phase('Орбита Земли', 'orbit', 16),
      phase('Перелёт к Марсу', 'marsTransfer', 158), phase('Спуск на Марс', 'marsLanding', 24),
      phase('Perseverance на поверхности', 'marsSurface', 12),
    ],
  },
  mars_science_laboratory: {
    title: '04 · Mars Science Laboratory', destination: 'Марс · Curiosity', payload: 'msl_ship', rover: 'curiosity',
    phases: [
      phase('Старт из Флориды', 'ascent', 52), phase('Орбита Земли', 'orbit', 16),
      phase('Перелёт к Марсу', 'marsTransfer', 158), phase('Спуск на Марс', 'marsLanding', 24),
      phase('Curiosity на поверхности', 'marsSurface', 12),
    ],
  },
  dart: {
    title: '05 · DART', destination: 'Диморф · система Дидимоса', payload: 'dart', target: 'didymos',
    phases: [
      phase('Запуск Falcon 9', 'ascent', 52), phase('Выведение и раскрытие ROSA', 'orbit', 16),
      phase('Перелёт к системе Дидимоса', 'asteroidTransfer', 124),
      phase('Отделение LICIACube', 'dartRelease', 8),
      phase('Финальный подлёт к Диморфу', 'dartApproach', DART_APPROACH_TIME),
      phase('Выброс породы после удара', 'dartAftermath', DART_AFTERMATH_TIME),
    ],
  },
  voyager_2: {
    title: '06 · Voyager 2', destination: 'Юпитер → Сатурн → дальний космос', payload: 'voyager',
    phases: [
      phase('Старт из Флориды', 'ascent', 52), phase('Орбита Земли', 'orbit', 16),
      phase('Перелёт к Юпитеру', 'jupiterTransfer', 164),
      phase('Облёт Юпитера', 'jupiterFlyby', 18),
      phase('Перелёт к Сатурну', 'saturnTransfer', 154),
      phase('Облёт Сатурна', 'saturnFlyby', 18),
      phase('К дальним планетам', 'escape', 110),
    ],
  },
  iss_resupply: {
    title: '07 · Снабжение МКС', destination: 'Орбита Земли · МКС', payload: 'dragon', target: 'iss', capsule: 'dragon',
    phases: [
      phase('Старт из Флориды', 'ascent', 52), phase('Орбита Земли', 'orbit', 16),
      phase('Сближение с МКС', 'stationApproach', 22),
      phase('Стыковка Dragon', 'docking', 14),
      phase('Возвращение к Земле', 'earthReturn', 118),
      phase('Спуск и приводнение', 'reentry', 32),
    ],
  },
};
export const customMission = {
  title: '08 · Свободный полёт', destination: 'Орбита Земли', payload: null,
  phases: [phase('Старт из Флориды', 'ascent', 52), phase('Орбита Земли', 'orbit', 16),
    phase('Возвращение к Земле', 'earthReturn', 118), phase('Спуск и приводнение', 'reentry', 32)],
};

export class FlightState extends EventTarget {
  constructor(id, mode = 'command', { crew = false } = {}) {
    super();
    this.mission = missions[id] ?? customMission;
    this.crew = missions[id] ? this.mission.crew === true : crew;
    this.id = id;
    this.mode = mode;
    this.phaseIndex = 0;
    this.time = 0;
    this.totalTime = 0;
    this.preflight = 5.5;
    this.countdown = 10;
    this.paused = false;
    this.complete = false;
    this.failed = false;
    this.altitude = 0;
    this.speed = 0;
    this.verticalSpeed = 0;
    this.pitch = 0;
    this.steeringPitch = 0;
    this.roll = 0;
    this.yaw = 0;
    this.throttle = 1;
    this.fuel = 100;
    this.position = launchUp.clone().multiplyScalar(EARTH_RADIUS);
    this.velocity = new Vector3();
    this.heading = launchUp.clone();
    this.progress = 0;
    this.engine = false;
    this.trimBurn = false;
    this.stageCoast = 0;
    this.waitingStageIgnition = false;
    this.surface = null;
    this.path = null;
    this.orbitAngle = 0;
    this.systems = new FlightSystems(MOON, MOON_RADIUS);
    this.reported = new Set();
    if (id === 'dart') {
      this.dartImpactOrigin = DART_NOMINAL_ORIGIN.clone();
      this.dartRange = DART_RELEASE_RANGE;
    }
  }
  get phase() { return this.mission.phases[this.phaseIndex]; }
  get kind() { return this.phase.kind; }
  get enginePower() {
    if (this.failed || this.complete) return 0;
    if (this.countdown > 0) return this.engine ? .16 + .18 * (1 - this.countdown / PREIGNITION_SECONDS) : 0;
    if (this.trimBurn) return .20;
    return this.engine && this.stageCoast <= 0 ? this.throttle * this.systems.powerLimit : 0;
  }
  report(type, detail = {}, once) {
    if (once && this.reported.has(once)) return;
    if (once) this.reported.add(once);
    this.dispatchEvent(new CustomEvent('mission', { detail: { type, detail } }));
  }
  fail(reason) {
    if (this.failed || this.complete) return;
    this.failed = true;
    this.failureReason = reason;
    this.engine = false;
    this.report('failure', { reason });
  }
  separateStage(delay) {
    this.stageCoast = delay;
    this.waitingStageIgnition = true;
    this.systems.temperature = .24;
    this.report('stage');
  }
  setMode(mode) {
    if (this.mode === mode) return;
    this.mode = mode;
    if (mode === 'manual') {
      this.velocity.copy(this.position).normalize().multiplyScalar(this.verticalSpeed / 1000)
        .addScaledVector(east, this.speed / 1000);
    }
    if (mode === 'command' && this.kind === 'ascent') {
      this.time = Math.cbrt(Math.max(0, this.altitude) / 200) * 52;
    }
  }
  advancePhase() {
    if (this.kind === 'dartApproach') this.report('probeImpact', { speedMps: DART_SPEED }, 'dartImpact');
    if (this.phaseIndex === this.mission.phases.length - 1) {
      this.complete = true;
      this.engine = false;
      this.report('success');
      return;
    }
    this.phaseIndex++;
    this.time = this.progress = 0;
    this.segmentStart = this.position.clone();
    this.engine = false;
    this.trimBurn = false;
    this.stageCoast = 0;
    this.waitingStageIgnition = false;
    this.systems.newPhase();
    const kind = this.kind;
    if (['moonLanding', 'moonSurface', 'marsLanding', 'marsSurface', 'reentry'].includes(kind)) {
      this.pitch = this.roll = 0;
    }
    if (kind === 'orbit') {
      this.speed = 7800;
      this.verticalSpeed = 0;
      this.pitch = 90;
      this.heading.copy(tangentAlong(this.position.clone().normalize(), this.heading));
    }
    if (kind === 'dartAftermath') {
      this.speed = this.altitude = 0;
      this.systems.integrity = 0;
      this.systems.link = false;
    }
    this.path = this.createPath(kind);
    this.report('phase', { kind });
  }
  createPath(kind) {
    const start = this.position;
    const heading = this.heading;
    if (kind === 'asteroidTransfer') {
      const arrival = dartWorldPosition(this.dartImpactOrigin, DART_RELEASE_RANGE);
      return transferRoute(start, heading, arrival, dartHeading, earthCenter);
    }
    const target = transferTargets[kind];
    if (target) {
      const departure = kind === 'saturnTransfer' ? JUPITER : earthCenter;
      return approachOrbit(start, heading, target.center, target.radius, departure);
    }
    if (kind === 'earthReturn') {
      const arrival = entryUp.clone().multiplyScalar(EARTH_RADIUS + 220);
      if (start.length() < EARTH_RADIUS + 1000) {
        const radial = start.clone().normalize();
        const along = tangentAlong(radial, entryUp);
        const arc = radial.angleTo(entryUp);
        const prograde = along.dot(heading) >= 0;
        return orbitArc(earthCenter, start, prograde ? along : along.negate(),
          prograde ? arc : 2 * Math.PI - arc, EARTH_RADIUS + 220);
      }
      return transferRoute(start, heading, arrival, entryHeading, MOON);
    }
    if (kind === 'escape') {
      const outward = start.clone().sub(SATURN).normalize();
      const destination = start.clone().addScaledVector(heading, 850000).addScaledVector(outward, 800000);
      return transferRoute(start, heading, destination, destination.clone().sub(SATURN).normalize(), SATURN);
    }
    if (kind === 'orbit') {
      const nextKind = this.mission.phases[this.phaseIndex + 1]?.kind;
      const destination = nextKind === 'asteroidTransfer' ? ASTEROID : transferTargets[nextKind]?.center;
      const sweep = destination ? departureSweep(start, heading, destination) : 1.05;
      return orbitArc(earthCenter, start, heading, sweep);
    }
    if (kind === 'stationApproach') return orbitArc(earthCenter, start, heading, .64, EARTH_RADIUS + 420);
    if (kind === 'docking') return orbitArc(earthCenter, start, heading, .28);
    if (kind === 'moonOrbit') return orbitArc(MOON, start, heading, 1.55);
    if (kind === 'lunarFlyby') return orbitArc(MOON, start, heading, 3.42);
    if (kind === 'separate') return orbitArc(MOON, start, heading, .23);
    if (kind === 'jupiterFlyby') {
      const sweep = departureSweep(start.clone().sub(JUPITER), heading, SATURN.clone().sub(JUPITER));
      return orbitArc(JUPITER, start, heading, sweep);
    }
    if (kind === 'saturnFlyby') return orbitArc(SATURN, start, heading, 2.2);
    return null;
  }
  playbackRate(requested) {
    if (isDartEncounter(this.kind)) return 1;
    if (this.countdown > 0 || this.kind === 'ascent' && this.totalTime < 1.45) return 1;
    if (this.kind === 'ascent' && this.mode === 'manual') return 1;
    const minimum = minimumScreenTime[this.kind];
    return minimum ? Math.min(requested, this.phase.duration / minimum) : requested;
  }
  update(dt, input = {}, requestedRate = 1, onPhaseChange) {
    let elapsed = 0;
    while (dt > 1e-8 && !this.paused && !this.failed && !this.complete) {
      if (this.preflight > 0) {
        this.report('preflight', { prepSeconds: PREIGNITION_SECONDS }, 'preflight');
        const step = Math.min(dt, this.preflight);
        dt -= step;
        this.preflight -= step;
        elapsed += step;
        if (this.preflight <= 1e-8) {
          this.preflight = 0;
          this.report('count', { value: 10 }, 'count:10');
        }
        continue;
      }
      const rate = this.playbackRate(requestedRate);
      if (this.countdown > 0) {
        const step = Math.min(this.countdown, dt * rate);
        const previous = this.countdown;
        this.countdown -= step;
        for (let value = Math.min(9, Math.ceil(previous) - 1); value > 0 && value >= this.countdown - 1e-8; value--) {
          this.report('count', { value }, `count:${value}`);
        }
        if (!this.engine && this.countdown <= PREIGNITION_SECONDS) {
          this.engine = true;
          this.report('enginePrep');
        }
        if (this.countdown <= 1e-8) {
          this.countdown = 0;
          this.report('liftoff');
        }
        dt -= step / rate;
        elapsed += step;
        continue;
      }
      const manualAscent = this.kind === 'ascent' && this.mode === 'manual';
      const untilBoundary = manualAscent ? .04 : Math.max(0, this.phase.duration - this.time);
      const step = Math.min(dt * rate, untilBoundary, .25);
      this.time += step;
      this.totalTime += step;
      elapsed += step;
      dt -= step / rate;
      this.progress = Math.min(1, this.time / this.phase.duration);
      const lastSurface = this.surface;
      this.stageCoast = Math.max(0, this.stageCoast - step);
      this.engine = ['ascent', 'moonLanding', 'rendezvous', 'marsLanding'].includes(this.kind);
      if (this.kind === 'ascent') this.ascent(step, input);
      else this.navigate(step / rate, input);
      this.trimBurn = false;
      this.systems.navigate(this, step, input);
      this.systems.tick(this, step, this.enginePower);
      if (this.waitingStageIgnition && this.enginePower > .02) {
        this.waitingStageIgnition = false;
        this.report('stageIgnition');
      }
      if (!this.failed && this.kind === 'ascent' && this.altitude >= .15) this.report('towerClear', {}, 'towerClear');
      if (this.surface && this.surface !== lastSurface) {
        this.report({ moon: 'moonTouch', mars: 'marsTouch', ocean: 'splash' }[this.surface]);
      }
      const ready = manualAscent
        ? this.altitude >= 200 && this.velocity.clone().cross(this.position.clone().normalize()).length() >= 6.5
        : step >= untilBoundary - 1e-8;
      if (ready && !this.failed) {
        const index = this.phaseIndex;
        this.advancePhase();
        if (index !== this.phaseIndex && onPhaseChange?.(this) === false) break;
      }
    }
    return elapsed;
  }
  ascent(dt, input) {
    if (this.mode === 'manual') {
      this.manualPhysics(dt, input);
      this.progress = Math.min(1, this.altitude / 200);
    } else {
      const u = Math.min(1, this.time / 52);
      this.altitude = 200 * u ** 3;
      this.verticalSpeed = 600 / 52 * u ** 2 * 1000;
      this.speed = 7800 * u ** 3;
      this.pitch = 88 * MathUtils.smoothstep(u, 0.18, 1);
      // Build downrange distance after the vertical climb over the coast.
      this.orbitAngle = 0.32 * u ** 5;
      this.fuel = 100 - u * 73;
    }
    if (this.mode === 'command') this.position.copy(launchUp).multiplyScalar(Math.cos(this.orbitAngle))
      .addScaledVector(east, Math.sin(this.orbitAngle)).multiplyScalar(EARTH_RADIUS + this.altitude);
    const radial = this.position.clone().normalize();
    if (this.mode === 'manual' && this.velocity.lengthSq() > 1e-10) this.heading.copy(this.velocity).normalize();
    else {
      const angle = MathUtils.degToRad(this.pitch);
      this.heading.copy(radial).multiplyScalar(Math.cos(angle))
        .addScaledVector(tangentAlong(radial, east), Math.sin(angle)).normalize();
    }
    this.engine = !this.failed && this.throttle > 0;
  }
  manualPhysics(dt, input) {
    const step = dt * 8;
    this.pitch = MathUtils.clamp(this.pitch + (input.pitch ?? 0) * dt * 22, -100, 110);
    this.roll += (input.roll ?? 0) * dt * 45;
    this.yaw += (input.yaw ?? 0) * dt * 25;
    const radial = this.position.clone().normalize();
    const north = new Vector3().crossVectors(radial, east).normalize();
    const pitch = MathUtils.degToRad(this.pitch);
    const yaw = MathUtils.degToRad(this.yaw);
    const direction = radial.clone().multiplyScalar(Math.cos(pitch))
      .addScaledVector(east, Math.sin(pitch) * Math.cos(yaw))
      .addScaledVector(north, Math.sin(pitch) * Math.sin(yaw)).normalize();
    const gravity = 398600.4418 / this.position.lengthSq();
    const drag = Math.exp(-Math.max(0, this.altitude) / 8) * 0.006 * this.velocity.length();
    const power = this.stageCoast > 0 ? 0 : this.throttle * this.systems.powerLimit;
    this.velocity.addScaledVector(direction, power * 0.025 * step)
      .addScaledVector(radial, -gravity * step).multiplyScalar(Math.max(0, 1 - drag * step));
    this.position.addScaledVector(this.velocity, step);
    this.altitude = this.position.length() - EARTH_RADIUS;
    this.verticalSpeed = this.velocity.dot(radial) * 1000;
    this.speed = this.velocity.length() * 1000;
    this.orbitAngle = Math.atan2(this.position.dot(east), this.position.dot(launchUp));
    this.fuel = Math.max(0, this.fuel - dt * power * 0.32);
    if (this.fuel === 0) this.throttle = 0;
    if (this.altitude < -0.01) {
      this.systems.integrity = 0;
      this.fail('impact');
      this.position.copy(radial).multiplyScalar(EARTH_RADIUS);
    }
    this.altitude = Math.max(0, this.altitude);
    this.engine = this.throttle > 0 && !this.failed;
  }
  navigate(dt, input) {
    if (this.kind === 'dartRelease' || isDartEncounter(this.kind)) {
      this.dartRange = this.kind === 'dartRelease' ? MathUtils.lerp(DART_RELEASE_RANGE, DART_APPROACH_RANGE, this.progress)
        : this.kind === 'dartApproach' ? dartRange(this.progress) : 0;
      dartWorldPosition(this.dartImpactOrigin, this.dartRange, this.position);
      this.heading.copy(dartHeading);
      this.altitude = this.dartRange * .001;
      this.speed = this.kind === 'dartAftermath' ? 0 : DART_SPEED;
      this.verticalSpeed = 0;
      return;
    }
    const u = MathUtils.smoothstep(this.progress, 0, 1);
    if (this.path) {
      this.path.sample(this.progress, this.position, this.heading);
      const profile = transferTargets[this.kind]?.speed ?? (this.kind === 'earthReturn' ? [2.5, 1.2, 7.8]
        : this.kind === 'asteroidTransfer' ? [10.6, 15, DART_SPEED / 1000] : null);
      if (profile) {
        const [departure, coast, arrival] = profile;
        this.speed = 1000 * MathUtils.lerp(departure, coast, MathUtils.smoothstep(this.progress, 0, .48));
        this.speed = MathUtils.lerp(this.speed, 1000 * arrival, MathUtils.smoothstep(this.progress, .52, 1));
      }
      if (['orbit', 'stationApproach', 'docking'].includes(this.kind)) {
        this.altitude = this.position.length() - EARTH_RADIUS;
        this.speed = 7800;
      }
      if (this.kind === 'moonOrbit' || this.kind === 'lunarFlyby' || this.kind === 'separate') this.speed = 1620;
    }
    if (this.kind === 'moonLanding' || this.kind === 'marsLanding') {
      const lunar = this.kind === 'moonLanding';
      const destination = lunar ? MOON : MARS;
      const radius = lunar ? MOON_RADIUS : 3389.5;
      const initialAltitude = Math.max(0, this.segmentStart.distanceTo(destination) - radius);
      const radial = this.segmentStart.clone().sub(destination).normalize();
      const landingUp = lunar ? moonUp : marsSites[this.id];
      const along = tangentAlong(radial, landingUp);
      const angle = radial.angleTo(landingUp) * u;
      const direction = radial.clone().multiplyScalar(Math.cos(angle)).addScaledVector(along, Math.sin(angle));
      this.heading.copy(along).multiplyScalar(Math.cos(angle)).addScaledVector(radial, -Math.sin(angle));
      const altitude = MathUtils.lerp(0.004, initialAltitude, (1 - u) ** 2);
      this.position.copy(destination).addScaledVector(direction, radius + altitude);
      this.altitude = this.position.distanceTo(destination) - radius;
      this.speed = (lunar ? 1620 : 5500) * (1 - u);
      if (!lunar) this.engine = this.altitude < 3 && !this.surface;
      if (this.progress === 1 && lunar) this.surface = 'moon';
    }
    if (this.kind === 'moonSurface') {
      this.surface = 'moon';
      this.altitude = 0;
      this.speed = 0;
    }
    if (this.kind === 'rendezvous') {
      this.surface = null;
      this.altitude = 120 * MathUtils.smoothstep(this.progress, 0, 0.78);
      const angle = .22 * MathUtils.smoothstep(this.progress, .16, 1);
      const radius = MOON_RADIUS + .004 + this.altitude;
      this.position.copy(MOON).addScaledVector(moonUp, Math.cos(angle) * radius).addScaledVector(moonEast, Math.sin(angle) * radius);
      this.heading.copy(moonEast).multiplyScalar(Math.cos(angle)).addScaledVector(moonUp, -Math.sin(angle));
      this.speed = 1620 * MathUtils.smoothstep(this.progress, 0, .78);
      this.engine = this.progress < 0.78;
    }
    if (this.kind === 'marsSurface') {
      this.surface = 'mars';
      this.altitude = 0;
      this.speed = 0;
    }
    if (this.kind === 'reentry') {
      const recovery = reentryProfile(this.progress);
      this.altitude = recovery.altitude;
      const angle = entryArc * MathUtils.smoothstep(this.progress, 0, .62);
      const radius = EARTH_RADIUS + this.altitude;
      this.position.copy(entryUp).multiplyScalar(Math.cos(angle) * radius).addScaledVector(entryHeading, Math.sin(angle) * radius);
      this.heading.copy(entryHeading).multiplyScalar(Math.cos(angle)).addScaledVector(entryUp, -Math.sin(angle));
      this.speed = recovery.speed;
      this.verticalSpeed = -recovery.speed;
      this.engine = false;
      if (recovery.opening >= .85) this.report('parachutes', {}, 'parachutes');
      if (recovery.landed) this.surface = 'ocean';
    }
    if (this.mode === 'manual' && this.kind !== 'reentry') {
      this.steeringPitch = MathUtils.clamp(this.steeringPitch + (input.pitch ?? 0) * dt * 25, -35, 35);
      this.roll += (input.roll ?? 0) * dt * 45;
      this.yaw += (input.yaw ?? 0) * dt * 25;
    }
  }
}
