import { Box3, Group, MathUtils, Matrix4, Quaternion, Vector3 } from 'three';
import { dockingPort, findPart } from './flight-layout.mjs';

export const orbitalPayloads = {
  apollo_docked: ['columbia_csm', 'eagle_lm'],
  orion: ['orion_esm', 'orion_cma', 'orion_cm'],
  mars2020_ship: ['perseverance_spacecraft'],
  msl_ship: ['curiosity_spacecraft'],
  dart: ['dart'],
  voyager: ['voyager_2'],
  dragon: ['cargo_dragon_2'],
};
export const fairingParts = [
  'sla', 'launch_escape', 'orion_las', 'esm_fairing_01', 'esm_fairing_02', 'esm_fairing_03',
  'atlas_v_fairing_l', 'atlas_v_fairing_r', 'falcon9_fairing_l', 'falcon9_fairing_r',
  'titan_centaur_fairing_l', 'titan_centaur_fairing_r',
];

const up = new Vector3(0, 1, 0);
const pitch = new Vector3(1, 0, 0);
const ease = MathUtils.smoothstep;

export function captureParts(parent, model, ids) {
  const parts = ids.map(id => findPart(model, id));
  if (!parts.length || parts.some(part => !part)) return null;
  if (parts.length === 1) {
    parent.attach(parts[0]);
    return parts[0];
  }
  const group = new Group();
  parent.add(group);
  for (const part of parts) group.attach(part);
  return group;
}

export function relativeBounds(model, reference) {
  model.updateWorldMatrix(true, true);
  const inverse = reference.matrixWorld.clone().invert();
  const matrix = new Matrix4();
  const result = new Box3();
  model.traverse(node => {
    if (!node.isMesh) return;
    if (!node.geometry.boundingBox) node.geometry.computeBoundingBox();
    result.union(node.geometry.boundingBox.clone().applyMatrix4(matrix.multiplyMatrices(inverse, node.matrixWorld)));
  });
  return result;
}

export function createDepartures(scene) {
  const group = new Group();
  scene.add(group);
  const objects = [];
  return {
    release(part, velocity, spin = .16, lifetime = 12) {
      if (!part) return;
      const pivot = new Group();
      const center = new Box3().setFromObject(part, true).getCenter(new Vector3());
      pivot.position.copy(center);
      group.add(pivot);
      pivot.attach(part);
      objects.push({ pivot, center, velocity, spin, lifetime, elapsed: 0 });
    },
    update(dt) {
      for (let i = objects.length - 1; i >= 0; i--) {
        const { pivot, center, velocity, spin, lifetime } = objects[i];
        const t = objects[i].elapsed += dt;
        pivot.position.copy(center).addScaledVector(velocity, t * (.32 + .34 * t));
        pivot.rotation.set(t * spin, t * spin * .43, -t * spin * .74);
        if (t >= lifetime) {
          pivot.removeFromParent();
          objects.splice(i, 1);
        }
      }
    },
    reset() { group.clear(); objects.length = 0; },
  };
}

export function apolloTransposition(payload) {
  const csm = findPart(payload, 'columbia_csm');
  const eagle = findPart(payload, 'eagle_lm');
  const start = csm.position.clone();
  const attitude = csm.quaternion.clone();
  const turn = new Quaternion();
  const offset = new Vector3();
  return (p) => {
    csm.position.copy(start).addScaledVector(up, 13 * ease(p, 0, .42));
    csm.quaternion.copy(attitude).multiply(turn.setFromAxisAngle(pitch, Math.PI * ease(p, .24, .64)));
    if (p > .64) {
      offset.copy(payload.worldToLocal(dockingPort(eagle))).sub(payload.worldToLocal(dockingPort(csm)));
      csm.position.addScaledVector(offset, ease(p, .64, 1));
    }
  };
}

export function deploymentPose(payload, deployed) {
  const targets = new Map();
  const joints = [];
  deployed?.traverse(node => {
    const id = node.userData.partId;
    if (id && /wing_\d+$|\.deployment$|^voyager_(mag_boom|rtg_boom|radio_antennas)$/.test(id)) targets.set(id, node.quaternion);
  });
  payload.traverse(node => {
    const target = targets.get(node.userData.partId);
    if (target && node.quaternion.angleTo(target) > .005) joints.push({ node, start: node.quaternion.clone(), target });
  });
  return p => {
    const angle = ease(p, .25, 1);
    for (const { node, start, target } of joints) node.quaternion.slerpQuaternions(start, target, angle);
  };
}
