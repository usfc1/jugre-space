import {
  Box3, BufferGeometry, DirectionalLight, Euler, Float32BufferAttribute, Group, HemisphereLight,
  LineBasicMaterial, LineSegments, Matrix4, Quaternion, Scene, Vector3, MathUtils,
} from 'three';
import { ASTEROID, FlightState, FLORIDA, MARS, MOON, PREIGNITION_SECONDS, east, launchUp } from './flight-missions.mjs';
import { airDensity } from './flight-systems.mjs';
import { createSpaceWorld, frameRotation } from './space-world.mjs';
import { makeAscentSmoke, makeExhaust } from './flight-effects.mjs';
import { makeLandingGround } from './landing-ground.mjs';
import { dockingPort, findPart, positionColumbia } from './flight-layout.mjs';
import { createRecoveryView } from './recovery-view.mjs';
import { reentryProfile } from './reentry-profile.mjs';
import { detachFirstStage } from './engine-nozzles.mjs';
import { createAscentView } from './ascent-view.mjs';
import { createCabinInteriors } from './cabin-interior.mjs';
import { apolloTransposition, captureParts, createDepartures, deploymentPose, fairingParts, orbitalPayloads, relativeBounds } from './flight-maneuvers.mjs';
import { createDartEncounter } from './dart-encounter.mjs';
import { deployDartArrays, releaseLiciacube } from './dart-deployment.mjs';
import { isDartEncounter } from './dart-course.mjs';

const format = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 });
const PAD_HANDOFF_KM = 0.65;
const PAD_FADE_END_KM = 3.2;
const landerKinds = new Set(['moonLanding', 'moonSurface', 'rendezvous']);
const moonKinds = new Set(['moonOrbit', 'lunarFlyby', 'separate', ...landerKinds]);
const upperStages = { apollo_11: ['s_ii', 'interstage_2_3'], voyager_2: ['titan_stage_2'] };
const phaseLocation = {
  ascent: 'Кеннеди / LC-39A', orbit: 'Земля / орбита',
  moonOrbit: 'Луна / орбита', lunarFlyby: 'Луна / облёт', separate: 'Луна / орбита',
  moonLanding: 'Луна / Море Спокойствия', moonSurface: 'Луна / Море Спокойствия', rendezvous: 'Луна / выход на орбиту',
  marsLanding: 'Марс / район посадки', marsSurface: 'Марс / поверхность',
  jupiterFlyby: 'Юпитер / облёт', saturnFlyby: 'Сатурн / облёт',
  stationApproach: 'Земля / МКС', docking: 'Земля / МКС',
  dartRelease: 'Дидимос / отделение наблюдателя', dartApproach: 'Диморф / финальный подлёт',
  dartAftermath: 'Диморф / наблюдение удара',
  reentry: 'Атлантика / район приводнения',
};
const upAxis = new Vector3(0, 1, 0);
const upsideDown = new Quaternion().setFromAxisAngle(new Vector3(1, 0, 0), Math.PI);
const flightScene = new Scene();
flightScene.background = null;
const ambient = new HemisphereLight(0x829dc5, 0x161920, 0.7);
const sun = new DirectionalLight(0xffefd8, 2.6);
sun.position.set(-45, 70, 45);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -50, right: 50, top: 50, bottom: -50, near: 1, far: 200 });
sun.shadow.normalBias = 0.025;
flightScene.add(ambient, sun);

export function setupFlightView({ launch, camera, controls, loader, decode, audio, suits, textures, onStart, onStop }) {
  const panel = document.querySelector('#flight-panel');
  const start = document.querySelector('#flight-start');
  const stageList = document.querySelector('#flight-stages');
  const mode = document.querySelector('#flight-mode');
  const warp = document.querySelector('#flight-warp');
  const throttle = document.querySelector('#flight-throttle');
  const map = document.querySelector('#flight-map');
  const mapContext = map.getContext('2d');
  const mapToggle = document.querySelector('#flight-map-toggle');
  const planetCamera = document.querySelector('#flight-planet');
  const eventText = document.querySelector('#flight-event');
  const banner = document.querySelector('#flight-banner');
  const status = document.querySelector('#flight-status');
  const stopButton = document.querySelector('#flight-stop');
  const cockpit = document.querySelector('#cockpit-hud');
  const dartReplay = document.querySelector('#flight-dart-replay');
  const cameraButtons = [...document.querySelectorAll('[data-flight-camera]')];
  const keys = new Set();
  const pointers = new Map();
  const ship = new Group();
  const debris = new Group();
  const nearby = new Group();
  const surfaceHardware = new Group();
  flightScene.add(ship, debris, nearby, surfaceHardware);
  const departures = createDepartures(flightScene);
  const bridle = new LineSegments(new BufferGeometry(), new LineBasicMaterial({ color: 0xebe1bc }));
  bridle.geometry.setAttribute('position', new Float32BufferAttribute(new Float32Array(18), 3));
  bridle.frustumCulled = false;
  bridle.visible = false;
  flightScene.add(bridle);
  let surfaceGroundY = 0;
  const exhaust = makeExhaust();
  ship.add(exhaust.root);
  const ascentSmoke = makeAscentSmoke();
  flightScene.add(ascentSmoke.root);
  const ground = makeLandingGround(suits.apollo);
  flightScene.add(ground.group);
  const cabins = createCabinInteriors(suits);
  const recovery = createRecoveryView();
  flightScene.add(recovery.group);
  const climbFrame = new Quaternion();
  const climbBasis = new Matrix4();
  const climbUp = new Vector3();
  const climbEast = new Vector3();
  const climbSouth = new Vector3();
  const climbDaylight = new Vector3();
  const flightFrame = new Quaternion();
  const inverseFrame = new Quaternion();
  const levelFrame = new Quaternion();
  const routeAttitude = new Quaternion();
  const turn = new Quaternion();
  const manualAttitude = new Quaternion();
  const manualAngles = new Euler();
  const forward = new Vector3();
  const desiredForward = new Vector3();
  const padBackgroundCamera = camera.clone();
  const launchSouth = new Vector3().crossVectors(east, launchUp);
  const padFrame = new Quaternion().setFromRotationMatrix(new Matrix4().makeBasis(east, launchUp, launchSouth));
  const padToFlight = new Quaternion();
  const flightToPad = new Quaternion();
  const emitter = new Vector3();
  const ascentOrigin = new Vector3();
  const padCenter = new Vector3();
  const padOffset = new Vector3();
  const lastPadOffset = new Vector3();
  const padMotion = new Vector3();
  const vesselCenter = new Vector3();
  const receiverOffset = new Vector3();
  const cabinPoint = new Vector3();
  const cabinDirection = new Vector3();
  const cabinFrame = new Quaternion();
  const cameraInverse = new Quaternion();
  function updatePadOffset() {
    padOffset.set(state.position.dot(east), 0, state.position.dot(launchSouth)).multiplyScalar(1000);
  }
  const previousClimbOffset = new Vector3();
  const nextClimbOffset = new Vector3();
  let guideClimb = true;
  let cameraMove;
  controls.addEventListener('start', () => {
    recovery.releaseCamera();
    guideClimb = false;
    cameraMove = undefined;
  });
  const cache = new Map();
  const previousAutoClear = true;
  let space;
  let ascentView;
  let loading = false;
  let active = false;
  let state;
  let snapshot;
  let visual;
  let halfHeight = 50;
  let ascentOriginHeight = 0;
  let width = 10;
  let sceneSpace = false;
  let runToken = 0;
  let nearbyType;
  let eagleOnPorts = false;
  let presentation;
  let staged = false;
  let upperStaged = false;
  let boostersReleased = false;
  let debrisTime = 0;
  const debrisDirection = new Vector3(0, -1, 0);
  let seconds = 0;
  let recoverySeconds = 0;
  let lastHud = 0;
  let lastMap = 0;
  let globeMap = false;
  let track = [];
  let bodyView = null;
  let cabin = false;
  let cameraId = 'ship';
  let steering = false;
  let lastCountTime = 0;
  let currentAsset;
  let cabinPointer;
  let dartEncounter;
  let dartRelease;

  const viewport = controls.domElement;
  viewport.addEventListener('pointerdown', event => {
    if (!active || !cabin || !cabins.name || event.button !== 0) return;
    cabinPointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
    viewport.setPointerCapture(event.pointerId);
  });
  viewport.addEventListener('pointermove', event => {
    if (event.pointerId !== cabinPointer?.id || !cabin) return;
    cabins.look(event.clientX - cabinPointer.x, cabinPointer.y - event.clientY);
    cabinPointer.x = event.clientX;
    cabinPointer.y = event.clientY;
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) viewport.addEventListener(type, event => {
    if (event.pointerId === cabinPointer?.id) cabinPointer = undefined;
  });

  const model = (id) => {
    if (!cache.has(id)) {
      const block = document.getElementById(`flight-data-${id}`);
      if (!block) return Promise.reject(new Error(`Flight model ${id} is missing`));
      cache.set(id, loader.parseAsync(decode(block.textContent).buffer, '').then(({ scene }) => scene)
        .catch((error) => { cache.delete(id); throw error; }));
    }
    return cache.get(id);
  };
  let missionModels = new Map();
  function announce(text) { eventText.textContent = text; }

  function radioEvent(event) { audio.mission(event.detail, state); }

  function countdownDelta() {
    const now = performance.now();
    const delta = Math.max(0, (now - lastCountTime) / 1000);
    lastCountTime = now;
    return delta;
  }

  function settleCountdown() {
    const elapsed = countdownDelta();
    if (state.countdown > 0 && !state.paused) {
      seconds += state.update(Math.min(state.preflight + state.countdown, elapsed));
    }
  }

  function findVesselCenter() {
    if (sceneSpace) return vesselCenter.copy(ship.position);
    return vesselCenter.copy(padOffset).setY(state.altitude * 1000 + ascentOriginHeight);
  }

  function aimCabin() {
    if (!cabin) { cabins.hide(); return; }
    if (state.kind === 'moonSurface') {
      cabins.hide();
      ground.helmet.getWorldPosition(cabinPoint);
      camera.position.copy(cabinPoint).addScaledVector(upAxis, .245);
      controls.target.set(0, ground.group.position.y + halfHeight * .9, 0);
      camera.lookAt(controls.target);
      return;
    }
    cabinFrame.setFromEuler(manualAngles.set(0, MathUtils.degToRad(state.roll + state.yaw), -MathUtils.degToRad(state.pitch)));
    if (state.crew && cabins.pose(visual, landerKinds.has(state.kind), camera, controls,
      sceneSpace ? null : findVesselCenter(), cabinFrame)) return;
    const attitude = sceneSpace ? ship.quaternion : cabinFrame;
    cabinPoint.set(0, halfHeight * .73, width * .19).applyQuaternion(attitude).add(findVesselCenter());
    cabinDirection.set(.72, .33, .67).normalize().applyQuaternion(attitude);
    camera.position.copy(cabinPoint);
    controls.target.copy(cabinPoint).addScaledVector(cabinDirection, 15);
    camera.lookAt(controls.target);
  }

  function mixAudio() {
    const emitter = findVesselCenter();
    receiverOffset.copy(emitter).sub(camera.position);
    const distance = receiverOffset.length();
    receiverOffset.applyQuaternion(cameraInverse.copy(camera.quaternion).invert());
    const listenerAltitude = state.altitude + (camera.position.y - emitter.y) * .001;
    audio.mix({
      cabin, distance, engine: state.enginePower, pressure: state.systems.pressure,
      pan: MathUtils.clamp(receiverOffset.x / Math.max(distance, 1), -1, 1),
      density: bodyView ? 0 : Math.min(state.systems.density, airDensity(state.kind, listenerAltitude)),
    });
  }

  function updateFlightFrame(dt) {
    if (state.kind === 'ascent' || state.kind === 'orbit') {
      climbUp.copy(state.position).normalize();
      climbEast.copy(east).addScaledVector(climbUp, -east.dot(climbUp)).normalize();
      climbSouth.crossVectors(climbEast, climbUp);
      climbFrame.setFromRotationMatrix(climbBasis.makeBasis(climbEast, climbUp, climbSouth));
      flightFrame.copy(climbFrame);
    } else {
      let vertical;
      if (landerKinds.has(state.kind)) vertical = state.position.clone().sub(MOON);
      else if (state.kind === 'marsLanding' || state.kind === 'marsSurface') vertical = state.position.clone().sub(MARS);
      else if (state.kind === 'reentry') vertical = state.position.clone();
      if (vertical) {
        levelFrame.setFromUnitVectors(upAxis, vertical.normalize());
        flightFrame.slerp(levelFrame, 1 - Math.exp(-4 * dt));
      }
    }
    inverseFrame.copy(flightFrame).invert();
  }

  function updateShipAttitude(dt) {
    if (state.kind === 'ascent') {
      ship.rotation.set(0, MathUtils.degToRad(state.roll + state.yaw), -MathUtils.degToRad(state.pitch));
      routeAttitude.copy(ship.quaternion);
      return;
    }
    const upright = landerKinds.has(state.kind) || state.kind === 'marsLanding' || state.kind === 'marsSurface' || state.kind === 'reentry';
    if (upright) {
      const landing = state.kind === 'moonLanding' || state.kind === 'marsLanding';
      const tilt = landing ? -.26 * Math.sin(Math.PI * state.progress) ** 2
        : state.kind === 'rendezvous' ? .30 * Math.sin(Math.PI * MathUtils.smoothstep(state.progress, .17, .75)) : 0;
      desiredForward.copy(state.heading).applyQuaternion(inverseFrame);
      desiredForward.y = 0;
      desiredForward.normalize().multiplyScalar(tilt).add(upAxis).normalize();
      routeAttitude.rotateTowards(turn.setFromUnitVectors(upAxis, desiredForward), 4 * dt);
    } else {
      desiredForward.copy(state.heading).applyQuaternion(inverseFrame);
      forward.set(0, currentAsset === 'dart' ? 0 : 1, currentAsset === 'dart' ? 1 : 0).applyQuaternion(routeAttitude);
      turn.setFromUnitVectors(forward, desiredForward).multiply(routeAttitude);
      routeAttitude.rotateTowards(turn, 5 * dt);
    }
    ship.quaternion.copy(routeAttitude);
    if (state.mode === 'manual' && !upright) {
      manualAngles.set(MathUtils.degToRad(state.yaw), MathUtils.degToRad(state.roll), -MathUtils.degToRad(state.steeringPitch));
      ship.quaternion.multiply(manualAttitude.setFromEuler(manualAngles));
    }
  }

  function climbOffset(altitude, target) {
    const progress = MathUtils.smoothstep(altitude, 0.08, 4);
    const distance = Math.max(14, halfHeight * 4.1, width * 3.4);
    return target.set(.79, MathUtils.lerp(.27, .12, progress), .58).multiplyScalar(distance);
  }

  function guideLaunchCamera(altitude) {
    if (!guideClimb || staged || bodyView || cabin) return;
    climbOffset(altitude, nextClimbOffset);
    camera.position.add(nextClimbOffset).sub(previousClimbOffset);
    previousClimbOffset.copy(nextClimbOffset);
  }

  function frameShip(distance = Math.max(halfHeight * 4, width * 2.7), smooth = false, target) {
    if (bodyView || cabin) return;
    const d = MathUtils.clamp(distance, 9, 420);
    const center = target ?? (visual ? new Box3().setFromObject(visual, true).getCenter(new Vector3()) : new Vector3());
    if (smooth) {
      const direction = camera.position.clone().sub(controls.target).normalize();
      cameraMove = { time: 0, from: camera.position.clone(), look: controls.target.clone(), center,
        position: direction.multiplyScalar(d).add(center) };
    } else {
      cameraMove = undefined;
      camera.position.set(d * 0.42, d * 0.22, d).add(center);
      controls.target.copy(center);
    }
    const currentDistance = camera.position.distanceTo(controls.target);
    controls.minDistance = Math.min(Math.max(2.5, halfHeight * 0.8), currentDistance);
    controls.maxDistance = Math.max(250, halfHeight * 14, currentDistance);
    controls.update();
  }
  function replaceVisual(root, recenter = true) {
    visual?.removeFromParent();
    visual = root;
    const box = new Box3().setFromObject(root, true);
    const center = box.getCenter(new Vector3());
    if (recenter) root.position.sub(center);
    const size = box.getSize(new Vector3());
    halfHeight = size.y / 2;
    width = Math.max(size.x, size.z);
    root.traverse((part) => { if (part.isMesh) part.castShadow = part.receiveShadow = true; });
    ship.add(root);
    exhaust.bind(root);
    if (sceneSpace) frameShip(undefined, true);
  }
  function stripServiceModule(root) {
    const pieces = ['apollo_sm', 'orion_esm', 'orion_cma', 'dragon_trunk'].map(id => findPart(root, id)).filter(Boolean);
    for (const item of pieces) departures.release(item, departureVector(0, -4.1, 1.4), .20);
    return pieces.length > 0;
  }
  function showShip(asset) {
    const key = asset;
    if (key === currentAsset) return;
    const clone = missionModels.get(asset).clone(true);
    replaceVisual(clone);
    currentAsset = key;
  }

  function departureVector(x, y, z) { return new Vector3(x, y, z).applyQuaternion(ship.quaternion); }

  function present(label, duration, pose, finish) {
    presentation = { label, duration, pose, finish, time: 0 };
    announce(label);
  }

  function adopt(root, asset, label, duration, pose, upright = false, settling = 1) {
    visual = root;
    currentAsset = asset;
    const bounds = relativeBounds(root, ship);
    const size = bounds.getSize(new Vector3());
    halfHeight = size.y / 2;
    width = Math.max(size.x, size.z);
    const from = root.position.clone();
    const startRotation = root.quaternion.clone();
    const targetRotation = upright ? new Quaternion() : startRotation;
    const target = from.clone().sub(bounds.getCenter(new Vector3()));
    if (upright) {
      const local = relativeBounds(root, root);
      target.copy(local.getCenter(new Vector3())).multiplyScalar(-1);
      halfHeight = local.getSize(size).y / 2;
      width = Math.max(size.x, size.z);
    }
    exhaust.bind(root);
    const startCenter = bounds.getCenter(new Vector3()).applyQuaternion(ship.quaternion).add(ship.position);
    frameShip(Math.max(24, halfHeight * 5.2, width * 4), true, startCenter);
    present(label, duration, p => {
      const u = MathUtils.smoothstep(p, 0, settling);
      root.position.lerpVectors(from, target, u);
      root.quaternion.slerpQuaternions(startRotation, targetRotation, u);
      pose?.(p);
    }, () => {
      const deployedSize = relativeBounds(root, ship).getSize(new Vector3());
      halfHeight = deployedSize.y / 2;
      width = Math.max(deployedSize.x, deployedSize.z);
      frameShip(undefined, true);
    });
  }

  function deployPayload() {
    const asset = state.mission.payload;
    const previous = visual;
    const payload = captureParts(ship, previous, orbitalPayloads[asset] ?? []);
    if (!payload) { showShip(asset); return; }
    for (const [i, id] of fairingParts.entries()) {
      const angle = i * 2.399963;
      departures.release(findPart(previous, id), departureVector(5 * Math.cos(angle), .6, 5 * Math.sin(angle)), .34, 7);
    }
    departures.release(previous, departureVector(0, -10, 1.7), .055, 14);
    const apollo = asset === 'apollo_docked';
    const dart = asset === 'dart';
    const pose = apollo ? apolloTransposition(payload) : dart
      ? deployDartArrays(payload, missionModels.get(asset), cover => departures.release(cover, departureVector(0, .4, 2), .16, 7))
      : deploymentPose(payload, missionModels.get(asset));
    adopt(payload, asset, apollo ? 'Разворот Columbia и стыковка с Eagle' : dart
      ? 'Отделение DART и раскрытие солнечных панелей ROSA' : 'Отделение аппарата от разгонной ступени',
      apollo ? 6.2 : dart ? 4.8 : 3.2, p => {
        pose(p);
        if (apollo && p >= 1) state.report('dock', { target: 'eagle' }, 'apolloTransposition');
      });
  }

  function landOnMars() {
    const roverId = state.mission.rover;
    const rover = captureParts(ship, visual, [roverId]);
    if (!rover) { showShip(roverId); return; }
    const crane = findPart(visual, 'mars_descent_stage');
    const previous = visual;
    previous.removeFromParent();
    if (crane) {
      crane.removeFromParent();
      ship.add(crane);
      crane.quaternion.identity();
    }
    const tether = new Vector3();
    const cables = bridle.geometry.attributes.position;
    const ends = [1, 2, 3].map(i => [findPart(crane, `bridle_0${i}`), findPart(rover, `mount_bridle_0${i}`)]);
    adopt(rover, roverId, 'Спуск марсохода и отвод небесного крана', 4.0, p => {
      const descent = MathUtils.smoothstep(p, 0, .64);
      rover.position.y += 5.0 * (1 - descent);
      if (descent === 1 && state.surface !== 'mars') {
        state.surface = 'mars';
        state.altitude = state.speed = 0;
        state.report('marsTouch');
      }
      if (!crane) return;
      const away = MathUtils.smoothstep(p, .64, 1);
      crane.position.set(away * 18, 7.4 + 4 * away, -away * 12);
      bridle.visible = away === 0;
      if (bridle.visible) {
        for (const [i, [top, bottom]] of ends.entries()) {
          (top ?? crane).getWorldPosition(tether);
          cables.setXYZ(i * 2, tether.x, tether.y, tether.z);
          (bottom ?? rover).getWorldPosition(tether);
          if (!bottom) tether.y += .9;
          cables.setXYZ(i * 2 + 1, tether.x, tether.y, tether.z);
        }
        cables.needsUpdate = true;
      }
      if (p >= 1) departures.release(crane, departureVector(8, 3, -5), .09, 5);
    }, true, .64);
  }
  function nearbyModel(id) {
    const root = missionModels.get(id).clone(true);
    const bounds = new Box3().setFromObject(root, true);
    root.position.sub(bounds.getCenter(new Vector3()));
    nearby.clear();
    nearby.add(root);
  }
  function separateLander() {
    const eagle = findPart(visual, 'eagle_lm');
    if (eagle) {
      nearby.position.copy(ship.position);
      nearby.quaternion.copy(ship.quaternion);
      nearby.attach(eagle);
      eagleOnPorts = true;
      currentAsset = 'columbia';
      frameShip(Math.max(34, halfHeight * 5), true);
    } else {
      showShip('columbia');
      nearbyModel('eagle');
      eagleOnPorts = false;
    }
    nearbyType = 'eagle';
  }
  function stageRocket() {
    if (!active || state.paused || state.failed || state.complete || state.kind !== 'ascent') return;
    if (staged) {
      if (upperStaged || state.altitude < 95 || !upperStages[state.id]) return;
      const pieces = upperStages[state.id].map(id => findPart(visual, id)).filter(Boolean);
      if (!pieces.length) return;
      for (const item of pieces) departures.release(item, departureVector(0, -8.7, .8), .08);
      upperStaged = true;
      exhaust.bind(visual);
      state.separateStage(.95);
      frameShip(undefined, true);
      announce('Вторая ступень отделена');
      return;
    }
    if (state.altitude < 8) return;
    const separation = detachFirstStage(visual, debris);
    if (!separation.parts.length) return;
    debrisDirection.copy(separation.direction);
    exhaust.bind(visual);
    staged = true;
    debrisTime = 0;
    state.separateStage(Math.max(.65, exhaust.clearance / 13 + .2));
    const size = relativeBounds(visual, ship).getSize(new Vector3());
    halfHeight = size.y / 2;
    width = Math.max(size.x, size.z);
    frameShip(undefined, true);
    announce('Первая ступень отделена');
  }
  function separateBoosters() {
    const parts = [];
    visual.traverse(item => {
      if (/^(sls_srb_[lr]|atlas_v_srb_\d+|titan_srb_[lr])$/.test(item.userData.partId ?? '')) parts.push(item);
    });
    for (const part of parts) {
      const radial = ship.worldToLocal(part.getWorldPosition(new Vector3()));
      radial.y = 0;
      radial.normalize().multiplyScalar(5.8).addScaledVector(upAxis, -5.1).applyQuaternion(ship.quaternion);
      departures.release(part, radial, .24, 9);
    }
    if (parts.length) { exhaust.bind(visual); announce('Боковые ускорители отделены'); }
    boostersReleased = true;
  }
  function renderStageList() {
    const fragment = document.createDocumentFragment();
    state.mission.phases.forEach((phase, i) => {
      const li = document.createElement('li');
      li.textContent = phase.label;
      li.dataset.stage = String(i);
      li.className = i < state.phaseIndex || state.complete ? 'done' : i === state.phaseIndex ? 'current' : '';
      fragment.append(li);
    });
    stageList.replaceChildren(fragment);
    if (stageList.children[state.phaseIndex]) stageList.scrollTop = Math.max(0, state.phaseIndex * 19 - 38);
  }

  function phaseChanged() {
    const kind = state.kind;
    const previousType = nearbyType;
    const pickup = kind === 'moonLanding' && previousType === 'eagle' ? captureParts(ship, nearby, ['eagle_lm'])
      : kind === 'earthReturn' && previousType === 'columbia' ? captureParts(ship, nearby, ['columbia_csm']) : null;
    if (kind === 'earthReturn' && previousType === 'iss') {
      departures.release(nearby.children[0], departureVector(-8, -9, -4), .016, 16);
    }
    nearbyType = undefined;
    nearby.clear();
    nearby.visible = true;
    nearby.rotation.set(0, 0, 0);
    nearby.position.set(0, 0, 0);
    if (kind !== 'rendezvous') surfaceHardware.clear();
    recovery.reset();
    recoverySeconds = 0;
    ground.group.visible = false;
    if (kind === 'orbit' && state.mission.payload) {
      deployPayload();
    }
    if (kind === 'separate') {
      separateLander();
      state.report('undock', {}, 'eagleSeparate');
    } else if (landerKinds.has(kind)) {
      if (pickup) {
        departures.release(visual, departureVector(-2, 4, -1), .05);
        adopt(pickup, 'eagle', 'Eagle разворачивается для посадки', 2.8, undefined, true);
      } else showShip('eagle');
      if (kind === 'rendezvous') {
        const descent = findPart(visual, 'eagle_descent');
        if (descent) {
          surfaceHardware.position.set(0, 0, 0);
          surfaceHardware.attach(descent);
          surfaceGroundY = new Box3().setFromObject(surfaceHardware, true).min.y;
          exhaust.bind(visual);
          frameShip(38, true, new Vector3(0, 3, 0));
        }
        nearby.visible = false;
        nearbyType = 'columbia';
        nearbyModel('columbia');
      }
    } else if (kind === 'earthReturn' && state.mission.capsule) {
      if (pickup) {
        departures.release(visual, departureVector(-2, -4, 1), .065);
        adopt(pickup, 'columbia', 'Columbia отходит от Eagle', 2.5, undefined, true);
      } else showShip(state.mission.capsule);
    } else if (kind === 'reentry' && state.mission.capsule) {
      showShip(state.mission.capsule);
      if (stripServiceModule(visual)) adopt(visual, state.mission.capsule, 'Отделение служебного модуля', 2.6, undefined, true);
    } else if (kind === 'marsLanding') {
      departures.release(findPart(visual, 'mars_cruise_stage'), departureVector(-4, 2.6, 1), .16);
    } else if (kind === 'marsSurface') {
      landOnMars();
    } else if (kind === 'stationApproach' || kind === 'docking') {
      nearbyType = 'iss';
      nearbyModel('iss');
    } else if (kind === 'dartRelease') {
      dartRelease = releaseLiciacube(visual, missionModels.get('dart'), missionModels.get('liciacube'));
      bodyView = null;
      cabin = false;
      cameraId = 'ship';
      cockpit.hidden = true;
      controls.enabled = true;
      const cube = findPart(visual, 'liciacube');
      const center = cube.getWorldPosition(new Vector3());
      const orientation = cube.parent.getWorldQuaternion(new Quaternion());
      cameraMove = { time: 0, from: camera.position.clone(), look: controls.target.clone(),
        center: center.clone().add(new Vector3(.15, 0, 1.3).applyQuaternion(orientation)),
        position: center.clone().add(new Vector3(3.1, 1.8, 6.6).applyQuaternion(orientation)) };
    } else if (isDartEncounter(kind)) {
      bodyView = null;
      cabin = false;
      cameraId = 'ship';
      cameraMove = undefined;
      cockpit.hidden = true;
      controls.enabled = false;
      cabins.hide();
      dartEncounter.update(state, 0, false);
    }
    renderStageList();
    if (kind === 'moonSurface') {
      frameShip(Math.max(35, width * 3.8), true, new Vector3(4, -halfHeight * .3, 2));
    }
    document.querySelector('#flight-map-title').textContent = ['ascent', 'orbit'].includes(kind)
      ? 'Флорида · старт и наземная трасса' : state.mission.destination;
    document.querySelector('#location-tag').textContent = phaseLocation[kind] ?? 'Межпланетный полёт';
    if (kind === 'reentry') {
      document.querySelector('#flight-map-title').textContent = 'Возвращение · Земля';
    }
    announce(presentation?.label ?? state.phase.label);
    telemetry();
    return !presentation;
  }

  function updateMap() {
    if (!space) return;
    const kind = state.kind;
    if (kind === 'dartRelease' || isDartEncounter(kind)) {
      mapToggle.hidden = true;
      map.setAttribute('aria-label', 'Схема системы Дидимоса и подлёта DART');
      document.querySelector('#flight-map-title').textContent = 'Дидимос и Диморф · схема подлёта';
      mapContext.fillStyle = '#101c29';
      mapContext.fillRect(0, 0, map.width, map.height);
      mapContext.strokeStyle = '#75889666';
      mapContext.beginPath(); mapContext.ellipse(162, 125, 220, 74, 0, 0, Math.PI * 2); mapContext.stroke();
      mapContext.fillStyle = '#8c8b83';
      mapContext.beginPath(); mapContext.arc(162, 125, 39, 0, Math.PI * 2); mapContext.fill();
      mapContext.fillStyle = '#b0a899';
      mapContext.beginPath(); mapContext.arc(382, 125, 13, 0, Math.PI * 2); mapContext.fill();
      mapContext.font = '13px Segoe UI,Arial';
      mapContext.fillStyle = '#e2e8e6';
      mapContext.fillText('Дидимос', 129, 184); mapContext.fillText('Диморф', 357, 96);
      const range = isDartEncounter(kind) ? dartEncounter.range : state.dartRange;
      const x = 382 - Math.min(1, range / 2600) * 130;
      mapContext.strokeStyle = '#e9b467';
      mapContext.setLineDash([4, 5]);
      mapContext.beginPath(); mapContext.moveTo(246, 125); mapContext.lineTo(369, 125); mapContext.stroke();
      mapContext.setLineDash([]);
      mapContext.fillStyle = '#8df5d4';
      mapContext.fillRect(x - 3, 122, 6, 6); mapContext.fillText('DART', x - 16, 150);
      return;
    }
    const name = bodyView ?? (moonKinds.has(kind) || kind === 'moonTransfer' ? 'Луна'
      : kind.startsWith('mars') ? 'Марс' : kind.startsWith('jupiter') ? 'Юпитер'
        : kind.startsWith('saturn') || kind === 'escape' ? 'Сатурн' : 'Земля');
    const body = space.bodies.find(item => item.name === name);
    const earth = name === 'Земля';
    const p = state.position.clone().sub(body.origin).normalize().applyQuaternion(body.mesh.quaternion.clone().invert());
    const lat = MathUtils.radToDeg(Math.asin(MathUtils.clamp(p.y, -1, 1)));
    const lon = MathUtils.radToDeg(Math.atan2(-p.z, p.x));
    if (earth && state.totalTime > 0 && ['ascent', 'orbit'].includes(kind)) {
      track.push([lon, lat]);
    }
    const zoom = earth && !globeMap && kind === 'ascent';
    const west = zoom ? -91 : -180;
    const east = zoom ? -67 : 180;
    const north = zoom ? 35 : 90;
    const south = zoom ? 23 : -90;
    const x = (longitude) => (longitude - west) / (east - west) * map.width;
    const y = (latitude) => (north - latitude) / (north - south) * map.height;
    const image = body.image;
    mapToggle.hidden = !earth || kind !== 'ascent';
    document.querySelector('#flight-map-title').textContent = zoom ? 'Флорида · старт и наземная трасса' : `${name} · карта`;
    if (image) mapContext.drawImage(image, (west + 180) / 360 * image.width, (90 - north) / 180 * image.height,
      (east - west) / 360 * image.width, (north - south) / 180 * image.height, 0, 0, map.width, map.height);
    else {
      mapContext.fillStyle = '#273440'; mapContext.fillRect(0, 0, map.width, map.height);
      mapContext.fillStyle = '#e4ebeb'; mapContext.fillText('Карта недоступна', 14, 25);
    }
    mapContext.fillStyle = '#061b2320'; mapContext.fillRect(0, 0, map.width, map.height);
    mapContext.strokeStyle = '#d0f3ef33'; mapContext.lineWidth = 1;
    for (let i = 1; i < 6; i++) {
      mapContext.beginPath(); mapContext.moveTo(i * map.width / 6, 0); mapContext.lineTo(i * map.width / 6, map.height); mapContext.stroke();
    }
    if (earth) {
      mapContext.strokeStyle = '#f7b660'; mapContext.lineWidth = 2;
      mapContext.beginPath();
      for (const [i, [longitude, latitude]] of track.entries()) {
        if (i === 0 || Math.abs(longitude - track[i - 1][0]) > 180) mapContext.moveTo(x(longitude), y(latitude));
        else mapContext.lineTo(x(longitude), y(latitude));
      }
      mapContext.stroke();
      mapContext.fillStyle = '#ffd69b';
      mapContext.beginPath(); mapContext.arc(x(FLORIDA.lon), y(FLORIDA.lat), 4, 0, Math.PI * 2); mapContext.fill();
      mapContext.font = '700 13px "Segoe UI",Arial';
      mapContext.fillText('Флорида', x(FLORIDA.lon) + 9, y(FLORIDA.lat) - 8);
    }
    if (state.position.distanceTo(body.origin) < body.radius * 3) {
      mapContext.fillStyle = '#a6f0d3';
      mapContext.beginPath(); mapContext.arc(x(lon), y(lat), 4, 0, Math.PI * 2); mapContext.fill();
    }
  }
  function telemetry() {
    const dartTerminal = isDartEncounter(state.kind);
    let altitude = state.altitude;
    if (state.id === 'dart' && !['ascent', 'orbit'].includes(state.kind)) {
      altitude = dartTerminal ? dartEncounter.range * .001 : state.kind === 'dartRelease' ? state.dartRange * .001
        : state.position.distanceTo(ASTEROID);
      document.querySelector('#flight-altitude-label').textContent = 'До Диморфа';
    } else if (!['ascent', 'orbit', 'reentry', 'stationApproach', 'docking', 'moonSurface', 'marsSurface'].includes(state.kind)) {
      const nearest = space.bodies.reduce((best, body) => {
        const distance = state.position.distanceTo(body.origin) - body.radius;
        return distance < best.distance ? { distance, name: body.name } : best;
      }, { distance: Infinity, name: 'Земля' });
      altitude = Math.max(0, nearest.distance);
      document.querySelector('#flight-altitude-label').textContent = `До поверхности · ${nearest.name}`;
    } else document.querySelector('#flight-altitude-label').textContent = 'Высота';
    document.querySelector('#flight-altitude').textContent = dartTerminal || state.kind === 'dartRelease'
      ? `${format.format(altitude * 1000)} м` : `${format.format(altitude)} км`;
    document.querySelector('#flight-speed').textContent = `${format.format(state.speed / 1000)} км/с`;
    document.querySelector('#flight-fuel').textContent = `${Math.round(state.fuel)} %`;
    const health = state.systems;
    const stats = [
      ['pressure', `${format.format(health.pressure)} кПа`, health.pressure >= 67],
      ['heat', `${Math.round(health.temperature * 100)} %`, health.temperature >= .97],
      ['integrity', `${Math.round(health.integrity * 100)} %`, health.integrity <= .30],
      ['link', health.link ? 'Связь' : 'Нет связи', !health.link],
    ];
    for (const [id, text, warning] of stats) {
      const item = document.querySelector(`#flight-${id}`);
      item.textContent = text;
      item.dataset.warning = String(warning);
    }
    const visualPitch = state.kind === 'ascent' ? state.pitch : MathUtils.radToDeg(upAxis.angleTo(forward.copy(upAxis).applyQuaternion(ship.quaternion)));
    document.querySelector('#flight-angle').textContent = `${Math.round(visualPitch)}° / ${Math.round(state.roll % 360)}°`;
    document.querySelector('#flight-progress').style.width = `${Math.round(state.progress * 100)}%`;
    document.querySelector('#flight-throttle-value').textContent = `${Math.round(state.throttle * 100)} %`;
    throttle.value = String(Math.round(state.throttle * 100));
    throttle.disabled = dartTerminal || state.countdown > 0 || state.paused || state.complete || state.failed;
    mode.disabled = dartTerminal;
    for (const button of document.querySelectorAll('[data-flight-input]')) button.disabled = dartTerminal;
    dartReplay.hidden = !(dartTerminal && state.complete);
    dartReplay.disabled = Boolean(dartEncounter?.replaying);
    if (state.countdown > 0) {
      banner.textContent = state.preflight > 0 ? 'Предстартовая проверка' : `T − ${Math.ceil(state.countdown - 1e-8)}`;
      status.textContent = state.paused ? 'Отсчёт на паузе' : state.engine
        ? 'Подготовка двигателей · раскрутка насосов' : 'Отвод мостиков · подготовка к старту';
    } else {
      banner.textContent = state.complete ? 'Миссия выполнена' : state.failed ? 'Полёт прерван'
        : state.totalTime < 1.45 ? 'T + 0 · Старт' : presentation?.label ?? state.phase.label;
      status.textContent = state.paused ? 'Полёт на паузе' : state.complete ? 'Задача миссии выполнена'
        : state.failed ? (state.failureReason === 'structure' ? 'Разрушение конструкции' : 'Столкновение с поверхностью')
          : presentation ? presentation.label : state.trimBurn ? 'Импульс коррекции траектории'
          : state.playbackRate(Number(warp.value)) < Number(warp.value) ? 'Манёвр · ускорение снижено' : 'Выполняется этап';
    }
    stopButton.textContent = state.countdown > 0 ? 'Отменить запуск' : 'Вернуться на старт';
    if (dartTerminal) {
      const aftermath = dartEncounter.aftermath;
      banner.textContent = aftermath ? 'DART · удар по Диморфу' : 'DART · финальное наведение DRACO';
      status.textContent = state.paused ? 'Полёт на паузе' : dartEncounter.replaying ? 'Повтор столкновения · замедленная съёмка'
        : aftermath ? state.complete ? 'Удар подтверждён · миссия выполнена' : 'Сигнал DART потерян · наблюдение выброса породы'
          : 'Автономное наведение · замедленная съёмка · 6,1 км/с';
      document.querySelector('#flight-speed').textContent = aftermath ? 'Удар 6,1 км/с' : '6,1 км/с';
      const link = document.querySelector('#flight-link');
      link.textContent = aftermath ? 'Сигнал потерян' : 'Связь';
      link.dataset.warning = String(aftermath);
      const integrity = document.querySelector('#flight-integrity');
      integrity.textContent = aftermath ? '0 %' : '100 %';
      integrity.dataset.warning = String(aftermath);
      if (aftermath) {
        announce('Контакт с поверхностью · наблюдение со стороны LICIACube');
      }
    }
    if (state.complete && state.kind === 'reentry') announce('Приводнение · миссия завершена');
    else if (state.kind === 'reentry' && reentryProfile(state.progress).landed) {
      banner.textContent = 'Касание воды';
      status.textContent = 'Капсула на воде · отцепление парашютов';
      announce('Приводнение · стабилизация капсулы');
    }
    const stage = document.querySelector('#flight-stage');
    stage.hidden = state.mode !== 'manual' || state.kind !== 'ascent';
    stage.disabled = state.paused || state.failed || (staged
      ? upperStaged || !upperStages[state.id] || state.altitude < 95 : state.altitude < 8);
    for (const button of cameraButtons) {
      if (button.dataset.flightCamera === 'cabin') button.textContent = dartTerminal ? 'DRACO' : state.kind === 'moonSurface' ? 'Шлем' : 'Борт';
      button.disabled = dartTerminal ? !['cabin', 'ship'].includes(button.dataset.flightCamera)
        || button.dataset.flightCamera === 'cabin' && dartEncounter.aftermath
        : !sceneSpace && !['cabin', 'ship'].includes(button.dataset.flightCamera);
      button.setAttribute('aria-pressed', String(button.dataset.flightCamera === cameraId));
    }
    planetCamera.disabled = !sceneSpace || dartTerminal;
    planetCamera.value = cameraId === 'planet' ? bodyView : '';
    cockpit.textContent = dartTerminal ? 'DRACO · ДИМОРФ · НАВЕДЕНИЕ' : state.kind === 'moonSurface' ? 'КАМЕРА ШЛЕМА' : cabins.name ?? 'БОРТОВАЯ КАМЕРА';
  }
  async function begin() {
    if (active || loading) return;
    snapshot = launch.snapshotForFlight();
    if (!snapshot) return;
    const token = ++runToken;
    loading = true;
    start.disabled = true;
    start.textContent = 'Подготовка полёта…';
    try {
      let crew = false;
      snapshot.model.traverse(node => { if (node.userData.role === 'crewCabin') crew = true; });
      const flight = new FlightState(snapshot.id, document.querySelector('#launch-flight-mode').value, { crew });
      const { payload, capsule, rover, target } = flight.mission;
      const ids = [...new Set([payload, capsule, rover, target, snapshot.id === 'apollo_11' ? 'eagle' : null,
        snapshot.id === 'dart' ? 'liciacube' : null].filter(Boolean))];
      const [world, loaded] = await Promise.all([
        space ?? createSpaceWorld(textures),
        Promise.all(ids.map(async (id) => [id, await model(id)])),
        audio.prepare(),
      ]);
      if (token !== runToken) return;
      space = world;
      missionModels = new Map(loaded);
      dartEncounter?.dispose();
      dartEncounter = snapshot.id === 'dart' ? createDartEncounter(missionModels.get('dart'), missionModels.get('didymos')) : undefined;
      if (dartEncounter) flight.dartImpactOrigin.copy(dartEncounter.impactOrigin);
      dartRelease = undefined;
      if (!ascentView) {
        ascentView = createAscentView(space.dayTexture, launch.terrainMaps);
      }
      space.reset();
      state = flight;
      state.addEventListener('mission', radioEvent);
      audio.begin();
      mode.value = state.mode;
      active = true;
      sceneSpace = false;
      lastPadOffset.set(0, 0, 0);
      ascentSmoke.reset();
      departures.reset();
      bridle.visible = false;
      presentation = undefined;
      cameraMove = undefined;
      staged = false;
      upperStaged = boostersReleased = false;
      ship.visible = true;
      nearby.scale.setScalar(1);
      nearby.position.set(0, 0, 0);
      debris.position.set(0, 0, 0);
      debris.quaternion.identity();
      seconds = 0;
      lastHud = lastMap = 0;
      bodyView = null;
      cameraId = 'ship';
      cabin = steering = false;
      cockpit.hidden = true;
      controls.enabled = true;
      currentAsset = undefined;
      track = [[FLORIDA.lon, FLORIDA.lat]];
      warp.value = '1';
      throttle.value = '100';
      ship.quaternion.identity();
      routeAttitude.identity();
      flightFrame.setFromUnitVectors(upAxis, launchUp);
      ship.position.set(0, 0, 0);
      debris.clear(); nearby.clear();
      surfaceHardware.clear();
      replaceVisual(snapshot.model.clone(true));
      ascentOriginHeight = launch.mountHeight + halfHeight;
      document.querySelector('#flight-pause').textContent = 'Пауза полёта';
      document.querySelector('#flight-pause').setAttribute('aria-pressed', 'false');
      onStart(state.mission.title);
      guideClimb = true;
      controls.enablePan = false;
      controls.minPolarAngle = .06;
      controls.maxPolarAngle = Math.PI - .06;
      controls.minDistance = Math.max(4, halfHeight * 1.45);
      controls.maxDistance = Math.max(110, halfHeight * 9);
      controls.target.set(0, launch.mountHeight + halfHeight * .93, 0);
      camera.position.copy(controls.target).add(climbOffset(0, previousClimbOffset));
      controls.update();
      panel.hidden = false;
      banner.hidden = false;
      document.querySelector('#flight-title').textContent = state.mission.title;
      document.querySelector('#flight-destination').textContent = state.mission.destination;
      launch.prepareFlight();
      updatePadOffset();
      mixAudio();
      lastCountTime = performance.now();
      state.report('preflight', { prepSeconds: PREIGNITION_SECONDS }, 'preflight');
      phaseChanged();
      telemetry();
      updateMap();
    } catch (error) {
      console.error(error);
      document.querySelector('#launch-status').textContent = 'Не удалось подготовить полёт. Попробуйте ещё раз.';
    } finally {
      loading = false;
      start.disabled = false;
      start.textContent = 'Начать полёт';
      start.blur();
    }
  }
  start.addEventListener('click', begin);
  const stop = () => {
    runToken++;
    settleCountdown();
    active = false;
    dartEncounter?.dispose();
    dartEncounter = undefined;
    dartRelease = undefined;
    dartReplay.hidden = true;
    if (state.countdown > 0) state.report('launchAbort');
    else audio.reset();
    state.removeEventListener('mission', radioEvent);
    controls.enabled = true;
    cockpit.hidden = true;
    keys.clear(); pointers.clear();
    panel.hidden = banner.hidden = true;
    eventText.textContent = '';
    launch.restoreFlight();
    onStop();
  };
  stopButton.addEventListener('click', stop);
  mode.addEventListener('change', () => { state?.setMode(mode.value); mode.blur(); });
  warp.addEventListener('change', () => warp.blur());
  throttle.addEventListener('input', () => { if (state) state.throttle = Number(throttle.value) / 100; });
  document.querySelector('#flight-stage').addEventListener('click', stageRocket);
  dartReplay.addEventListener('click', () => {
    if (!active || !state.complete || !dartEncounter) return;
    if (state.paused) document.querySelector('#flight-pause').click();
    cabin = false;
    cameraId = 'ship';
    cockpit.hidden = true;
    dartEncounter.replay();
    dartEncounter.update(state, 0, false);
    telemetry();
  });
  document.querySelector('#flight-pause').addEventListener('click', (event) => {
    settleCountdown();
    state.paused = !state.paused;
    audio.pause(state.paused);
    event.currentTarget.textContent = state.paused ? 'Продолжить полёт' : 'Пауза полёта';
    event.currentTarget.setAttribute('aria-pressed', String(state.paused));
    telemetry();
  });
  mapToggle.addEventListener('click', (event) => {
    globeMap = !globeMap;
    event.currentTarget.textContent = globeMap ? 'Флорида' : 'Карта мира';
    updateMap();
  });
  function focusBody(name) {
    bodyView = name;
    cameraMove = undefined;
    camera.position.copy(space.sunDirection).multiplyScalar(name === 'Сатурн' ? 150 : 85);
    camera.position.y += name === 'Сатурн' ? 40 : 0;
    controls.minDistance = 38; controls.maxDistance = 220;
    controls.target.set(0, 0, 0);
    controls.update();
  }
  planetCamera.addEventListener('change', () => {
    if (!planetCamera.value) return;
    cameraId = 'planet';
    cabin = false;
    cockpit.hidden = true;
    controls.enabled = true;
    focusBody(planetCamera.value);
    mixAudio();
    telemetry();
    updateMap();
    planetCamera.blur();
  });
  for (const button of cameraButtons) {
    button.addEventListener('click', () => {
      const id = button.dataset.flightCamera;
      cameraId = id;
      cabin = id === 'cabin';
      cameraMove = undefined;
      cockpit.hidden = !cabin;
      if (isDartEncounter(state.kind)) {
        controls.enabled = false;
        dartEncounter.update(state, 0, cabin);
        telemetry();
        return;
      }
      controls.enabled = !cabin;
      if (cabin) {
        bodyView = null;
        guideClimb = false;
        cabins.centerView();
        aimCabin();
      } else if (id === 'ship') {
        bodyView = null;
        guideClimb = false;
        if (sceneSpace) frameShip();
        else {
          controls.target.copy(findVesselCenter());
          camera.position.copy(controls.target).add(climbOffset(state.altitude, previousClimbOffset));
          controls.update();
        }
      }
      else {
        focusBody(id === 'earth' ? 'Земля' : 'Луна');
      }
      mixAudio();
      telemetry();
      updateMap();
    });
  }
  window.addEventListener('keydown', (event) => {
    if (!active || event.target.closest?.('dialog') || event.target.matches?.('select, textarea, input:not([type=range])')) return;
    if (event.target.matches?.('input[type=range]') && event.code.startsWith('Arrow')) return;
    if (event.target.matches?.('button') && event.code === 'Space') return;
    if (['Space', 'ShiftLeft', 'ControlLeft', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
    keys.add(event.code);
    if (event.repeat) return;
    if (event.code === 'Space' && state.mode === 'manual') stageRocket();
    if (!throttle.disabled && event.code === 'KeyZ') state.throttle = 1;
    if (!throttle.disabled && event.code === 'KeyX') state.throttle = 0;
    if (event.code === 'KeyP') document.querySelector('#flight-pause').click();
  });
  window.addEventListener('keyup', (event) => keys.delete(event.code));
  window.addEventListener('blur', () => { keys.clear(); pointers.clear(); });
  for (const button of document.querySelectorAll('[data-flight-input]')) {
    button.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      pointers.set(event.pointerId, button.dataset.flightInput);
      button.setPointerCapture(event.pointerId);
    });
    for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(event, (e) => pointers.delete(e.pointerId));
  }
  return {
    get active() { return active; },
    update(dt) {
      if (!active) return;
      const pressed = (code, touch) => keys.has(code) || [...pointers.values()].includes(touch);
      const input = {
        pitch: Number(pressed('KeyW', 'up') || keys.has('ArrowUp')) - Number(pressed('KeyS', 'down') || keys.has('ArrowDown')),
        roll: Number(pressed('KeyD', 'right') || keys.has('ArrowRight')) - Number(pressed('KeyA', 'left') || keys.has('ArrowLeft')),
        yaw: Number(keys.has('KeyE')) - Number(keys.has('KeyQ')),
      };
      if (!throttle.disabled && keys.has('ShiftLeft')) state.throttle = Math.min(1, state.throttle + dt * 0.3);
      if (!throttle.disabled && keys.has('ControlLeft')) state.throttle = Math.max(0, state.throttle - dt * 0.3);
      const wasComplete = state.complete;
      const wasFailed = state.failed;
      const countdownDt = countdownDelta();
      const stepTime = state.countdown > 0 ? Math.min(countdownDt, state.preflight + state.countdown + dt) : dt;
      const total = presentation ? 0 : state.update(stepTime, input, Number(warp.value), phaseChanged);
      if (!state.paused) {
        departures.update(dt);
        if (presentation) {
          presentation.time += dt;
          const p = Math.min(1, presentation.time / presentation.duration);
          presentation.pose(p);
          if (p === 1) {
            presentation.finish();
            presentation = undefined;
            announce(state.phase.label);
          }
        }
      }
      const moving = Boolean(input.pitch || input.yaw || input.roll);
      if (moving && !steering && cabin && state.crew && state.mode === 'manual' && total > 0 && state.countdown === 0) {
        audio.fx('suit', 'cabin', .7);
      }
      steering = moving;
      seconds += total;
      if (isDartEncounter(state.kind)) {
        dartEncounter.update(state, dt, cabin);
        if (dartEncounter.aftermath) { cabin = false; cameraId = 'ship'; cockpit.hidden = true; }
        audio.mix({ cabin: false, distance: 0, engine: 0, pressure: 0, pan: 0, density: 0 });
        if (!wasComplete && state.complete) renderStageList();
        telemetry();
        updateMap();
        return;
      }
      if (state.kind === 'dartRelease') dartRelease(state.progress);
      recoverySeconds += state.paused ? 0 : dt;
      updateFlightFrame(state.paused ? 0 : dt);
      const wasSpace = sceneSpace;
      sceneSpace ||= state.kind !== 'ascent' || state.altitude >= PAD_HANDOFF_KM;
      if (!wasSpace && sceneSpace) {
        controls.minAzimuthAngle = -Infinity; controls.maxAzimuthAngle = Infinity;
        controls.minPolarAngle = 0.02; controls.maxPolarAngle = Math.PI - 0.02;
        controls.enablePan = false;
        camera.near = 0.025; camera.far = 6000;
        camera.updateProjectionMatrix();
        padCenter.copy(lastPadOffset).setY(launch.flightHeight + ascentOriginHeight);
        padToFlight.copy(inverseFrame).multiply(padFrame);
        camera.position.sub(padCenter).applyQuaternion(padToFlight);
        controls.target.sub(padCenter).applyQuaternion(padToFlight);
        camera.quaternion.premultiply(padToFlight);
        controls.update();
      }
      if (!sceneSpace) {
        const altitude = state.altitude * 1000;
        const lift = altitude - launch.flightHeight;
        updatePadOffset();
        padMotion.copy(padOffset).sub(lastPadOffset).setY(lift);
        lastPadOffset.copy(padOffset);
        camera.position.add(padMotion);
        controls.target.add(padMotion);
        guideLaunchCamera(state.altitude);
        launch.flightPose(altitude, state.pitch, state.enginePower, seconds, padOffset.x, padOffset.z, state.roll + state.yaw);
        controls.update();
      } else {
        launch.flightBackdrop(seconds);
        if (state.kind === 'ascent' && guideClimb && !staged && !bodyView) {
          guideLaunchCamera(state.altitude);
          controls.update();
        }
        updateShipAttitude(state.paused ? 0 : dt);
        if (state.kind === 'ascent' && state.mode === 'command' && !state.paused) {
          if (!boostersReleased && state.altitude > 19) separateBoosters();
          if ((!staged && state.altitude > 40) || (staged && state.altitude > 112)) stageRocket();
        }
        if (state.kind === 'marsLanding') {
          if (state.progress >= .55) departures.release(findPart(visual, 'mars_heatshield'), departureVector(1.7, -5, 1), .22);
          if (state.progress >= .76) departures.release(findPart(visual, 'mars_backshell'), departureVector(-5, 2, 3), .19);
        }
        if (debris.children.length) {
          debrisTime += state.paused ? 0 : total;
          debris.position.copy(debrisDirection).multiplyScalar(debrisTime * 13);
          if (!state.paused) debris.rotation.z -= dt * 0.03;
          if (debrisTime > 25) debris.clear();
        }
        if (state.kind === 'separate' && nearby.children.length) {
          const p = MathUtils.smoothstep(state.progress, 0, 1);
          nearby.position.copy(ship.position);
          nearby.quaternion.copy(ship.quaternion);
          if (!eagleOnPorts) {
            nearby.quaternion.multiply(upsideDown);
            nearby.position.add(dockingPort(visual)).sub(dockingPort(nearby));
          }
          nearby.position.add(new Vector3(18 * p, 12 * p, 0).applyQuaternion(ship.quaternion));
        }
        else if (nearbyType === 'iss' && nearby.children.length) {
          const p = MathUtils.smoothstep(state.progress, 0, state.kind === 'docking' ? .82 : 1);
          nearby.position.set(0, 0, 0);
          nearby.quaternion.copy(ship.quaternion).multiply(upsideDown);
          const offset = state.kind === 'docking' ? new Vector3(0, 68 * (1 - p), 0)
            : new Vector3(78 * (1 - p), 68 + 252 * (1 - p), 35 * (1 - p));
          nearby.position.copy(dockingPort(visual)).sub(dockingPort(nearby)).add(offset.applyQuaternion(ship.quaternion));
          if (state.kind === 'docking' && offset.lengthSq() < .003 && !state.paused) {
            state.report('dock', { target: 'iss' }, 'issDock');
          }
        }
        else if (nearbyType === 'columbia') {
          positionColumbia(nearby, visual, state.progress);
          if (nearby.visible && nearby.children.length && !state.paused
            && dockingPort(visual).distanceToSquared(dockingPort(nearby)) < .003) {
            state.report('dock', { target: 'columbia' }, 'lunarDock');
          }
        }
        else nearby.position.set(0, 0, 0);
        const engine = state.trimBurn ? 0 : state.enginePower;
        const lunarEngine = landerKinds.has(state.kind);
        const vacuum = state.kind === 'ascent' ? MathUtils.smoothstep(state.altitude, 12, 90) : 1;
        ascentOrigin.copy(state.position).addScaledVector(climbUp, ascentOriginHeight * .001);
        emitter.set(0, -halfHeight, 0).applyQuaternion(ship.quaternion).applyQuaternion(flightFrame)
          .multiplyScalar(.001).add(ascentOrigin);
        if (state.kind === 'ascent') ascentSmoke.update(seconds, engine > .12 && state.altitude < 34, emitter, ascentOrigin, inverseFrame);
        else ascentSmoke.root.visible = false;
        exhaust.update(seconds, engine, lunarEngine ? 0.65 : Math.max(0.6, width * 0.6),
          lunarEngine ? 5 : Math.max(6, halfHeight * 1.1), vacuum);
        surfaceHardware.visible = state.kind === 'rendezvous' && state.altitude < 2;
        surfaceHardware.position.y = -state.altitude * 1000;
        const step = ground.update(state, state.kind === 'rendezvous' ? -surfaceGroundY : halfHeight, recoverySeconds);
        if (step && cabin && state.kind === 'moonSurface' && !state.paused) {
          audio.fx('step', 'cabin', .66);
          audio.fx('suit', 'cabin', .24);
        }
        recovery.update(state, ship, halfHeight, width, recoverySeconds, state.paused ? 0 : dt,
          bodyView || cabin ? null : camera, bodyView || cabin ? null : controls);
      }
      if (cameraMove && !state.paused && !cabin && !bodyView) {
        cameraMove.time += dt;
        const p = MathUtils.smoothstep(cameraMove.time, 0, 1.65);
        camera.position.lerpVectors(cameraMove.from, cameraMove.position, p);
        controls.target.lerpVectors(cameraMove.look, cameraMove.center, p);
        controls.update();
        if (p === 1) cameraMove = undefined;
      }
      aimCabin();
      if (!state.paused) cabins.update(dt);
      mixAudio();
      if (!wasComplete && state.complete) renderStageList();
      if (seconds - lastHud > 0.1 || state.paused || !wasComplete && state.complete || !wasFailed && state.failed) {
        telemetry(); lastHud = seconds;
      }
      if (seconds - lastMap > 0.4) { updateMap(); lastMap = seconds; }
    },
    render(renderer) {
      if (!active) return false;
      if (isDartEncounter(state.kind)) {
        dartEncounter.render(renderer, camera.aspect);
        return true;
      }
      if (!sceneSpace) {
        if (cabin) {
          launch.renderBackground(renderer, camera);
          if (cabins.name) {
            renderer.autoClear = false;
            renderer.clearDepth();
            renderer.render(cabins.scene, camera);
            renderer.autoClear = previousAutoClear;
          }
        }
        return cabin;
      }
      camera.updateMatrixWorld();
      space.update(state, camera, bodyView, flightFrame);
      const climb = !bodyView && (state.kind === 'ascent' || state.kind === 'orbit');
      let backdropOpacity = 1;
      if (climb) {
        climbDaylight.copy(climbEast).multiplyScalar(-.40).addScaledVector(climbUp, .78).addScaledVector(climbSouth, .48).normalize();
        backdropOpacity = MathUtils.smoothstep(state.altitude, PAD_HANDOFF_KM, PAD_FADE_END_KM);
        ascentView.update(state, camera, climbFrame, climbDaylight, ascentOriginHeight, backdropOpacity);
        sun.position.set(-40, 78, 48);
      } else if (recovery.active) sun.position.set(-35, 55, 75);
      else if (ground.marsAir > 0) sun.position.set(-57, 40, 58);
      else sun.position.copy(space.sunDirection).applyQuaternion(frameRotation.clone().invert()).multiplyScalar(90);
      ambient.intensity = climb ? MathUtils.lerp(1.5, .8, MathUtils.smoothstep(state.altitude, 4, 130))
        : recovery.active ? 1.35 : ground.marsAir > 0 ? 1.22 : 0.7;
      renderer.autoClear = false;
      renderer.clear();
      if (climb) {
        if (backdropOpacity < 1) {
          padBackgroundCamera.copy(camera, false);
          updatePadOffset();
          padCenter.copy(padOffset).setY(state.altitude * 1000 + ascentOriginHeight);
          flightToPad.copy(padFrame).invert().multiply(flightFrame);
          padBackgroundCamera.position.applyQuaternion(flightToPad).add(padCenter);
          padBackgroundCamera.quaternion.premultiply(flightToPad);
          padBackgroundCamera.near = 0.8;
          padBackgroundCamera.far = 65000;
          padBackgroundCamera.updateProjectionMatrix();
          launch.renderBackground(renderer, padBackgroundCamera);
        }
        renderer.render(ascentView.scene, camera);
      } else if (!recovery.active || recovery.skyBlend < 1 || bodyView) renderer.render(space.scene, space.camera);
      if (!bodyView) {
        if (recovery.active) renderer.render(recovery.background, camera);
        if (ground.marsAir > 0) renderer.render(ground.background, camera);
        renderer.clearDepth();
        const cameraHost = state.kind === 'moonSurface' ? ground.explorer : ship;
        const visible = cameraHost.visible;
        if (cabin) cameraHost.visible = false;
        try { renderer.render(flightScene, camera); }
        finally { cameraHost.visible = visible; }
        if (cabin && cabins.name) {
          renderer.clearDepth();
          renderer.render(cabins.scene, camera);
        }
      }
      renderer.autoClear = previousAutoClear;
      return true;
    },
  };
}
