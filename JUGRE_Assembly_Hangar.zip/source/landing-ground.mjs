import {
  AnimationMixer, BackSide, CanvasTexture, CatmullRomCurve3, CylinderGeometry, Group, InstancedMesh, MathUtils,
  Matrix4, Mesh, MeshStandardMaterial, PlaneGeometry, Quaternion, RepeatWrapping, Scene, ShaderMaterial,
  SphereGeometry, Vector3, SRGBColorSpace, Float32BufferAttribute,
} from 'three';

const random = (n) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const material = (color) => new MeshStandardMaterial({ color, roughness: 0.93 });
const white = material(0xe8e4d6);
const lunarPace = .7;

function makeMarsSky() {
  const scene = new Scene();
  const material = new ShaderMaterial({
    side: BackSide, depthWrite: false, depthTest: false, transparent: true,
    uniforms: { opacity: { value: 0 } },
    vertexShader: 'varying vec3 ray;void main(){ray=position;vec4 p=projectionMatrix*mat4(mat3(viewMatrix))*vec4(position,1.);gl_Position=p.xyww;}',
    fragmentShader: `
      varying vec3 ray;uniform float opacity;
      void main(){
        vec3 d=normalize(ray);
        vec3 c=mix(vec3(.61,.29,.15),vec3(.19,.11,.10),pow(max(0.,d.y),.46));
        float glow=pow(max(0.,dot(d,normalize(vec3(-.68,.36,.58)))),16.);
        c+=glow*vec3(.30,.28,.25);
        gl_FragColor=vec4(c,opacity);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const sky = new Mesh(new SphereGeometry(900, 32, 16), material);
  sky.frustumCulled = false;
  scene.add(sky);
  return { scene, material };
}

export function makeLandingGround(apolloSuit) {
  const group = new Group();
  const geometry = new PlaneGeometry(8192, 8192, 256, 256).rotateX(-Math.PI / 2);
  const positions = geometry.attributes.position;
  const craters = Array.from({ length: 55 }, (_, i) => ({
    x: (random(i) - 0.5) * 1400, z: (random(i + 80) - 0.5) * 1400, r: 9 + random(i + 30) * 52,
  }));
  const colors = [];
  for (let i = 0; i < positions.count; i++) {
    // Concentrate mesh vertices around the landing site, keeping the distant
    // terrain inexpensive while resolving small crater rims near the camera.
    const spread = (v) => Math.sign(v) * (Math.abs(v) / 4096) ** 1.7 * 4096;
    const x = spread(positions.getX(i));
    const z = spread(positions.getZ(i));
    positions.setX(i, x); positions.setZ(i, z);
    let y = Math.sin(x * 0.016 + Math.cos(z * 0.022)) * 3 + Math.cos(z * 0.011) * 2;
    for (const crater of craters) {
      const r = Math.hypot(x - crater.x, z - crater.z) / crater.r;
      if (r < 1.25) y += -Math.max(0, 1 - r * r) * crater.r * 0.13 + Math.exp(-((r - 1) ** 2) * 80) * crater.r * 0.04;
    }
    const safeZone = Math.min(1, Math.max(0, (Math.hypot(x, z) - 25) / 50));
    positions.setY(i, y * safeZone - (x * x + z * z) / (2 * 1737400));
    const tone = 0.78 + 0.10 * Math.sin(x * 0.037 + Math.sin(z * 0.041)) + 0.06 * Math.cos(z * 0.16 + x * 0.12);
    colors.push(tone, tone * 0.99, tone * 0.96);
  }
  geometry.setAttribute('color', new Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  const finish = material(0x8d8b85);
  finish.vertexColors = true;
  const soil = document.createElement('canvas');
  soil.width = soil.height = 256;
  const ctx = soil.getContext('2d');
  const pixels = ctx.createImageData(256, 256);
  for (let i = 0; i < 256 * 256; i++) {
    const tone = 145 + random(i + 20) * 70;
    pixels.data[i * 4] = pixels.data[i * 4 + 1] = pixels.data[i * 4 + 2] = tone;
    pixels.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(pixels, 0, 0);
  const texture = new CanvasTexture(soil);
  texture.colorSpace = SRGBColorSpace;
  texture.anisotropy = 16;
  texture.wrapS = texture.wrapT = RepeatWrapping;
  texture.repeat.set(512, 512);
  finish.map = texture;
  const ground = new Mesh(geometry, finish);
  ground.receiveShadow = true;
  group.add(ground);
  const marsGeometry = geometry.clone();
  const marsPositions = marsGeometry.attributes.position;
  const marsColors = marsGeometry.attributes.color;
  for (let i = 0; i < marsPositions.count; i++) {
    const x = marsPositions.getX(i);
    const z = marsPositions.getZ(i);
    const away = MathUtils.smoothstep(Math.hypot(x, z), 18, 90);
    const ridges = Math.sin(z * .027 + Math.sin(x * .014) * 1.7) ** 4;
    const basin = MathUtils.smoothstep(x * .62 + z * .43, 150, 1200);
    const roughness = 3 * Math.sin(x * .035 - z * .065) + 5 * Math.sin(z * .011 + x * .008);
    marsPositions.setY(i, away * (roughness + (9 + basin * 65) * ridges - 6 * basin));
    const streak = .72 + .16 * Math.sin(x * .018 + Math.sin(z * .044) * 1.5) + .09 * ridges;
    marsColors.setXYZ(i, streak, streak * .88, streak * .73);
  }
  marsGeometry.computeVertexNormals();
  const marsTerrain = new Mesh(marsGeometry, new MeshStandardMaterial({
    color: 0xb77c58, roughness: .98, vertexColors: true, map: texture,
  }));
  marsTerrain.receiveShadow = true;
  group.add(marsTerrain);
  const marsSky = makeMarsSky();
  let marsAir = 0;
  const rockFinish = material(0x77756e);
  const rocks = new InstancedMesh(new SphereGeometry(1, 7, 5), rockFinish, 500);
  const matrix = new Matrix4();
  for (let i = 0; i < 500; i++) {
    let x = (random(i + 100) - 0.5) * 800;
    const z = (random(i + 200) - 0.5) * 800;
    if (Math.hypot(x, z) < 20) x += 25;
    const r = 0.2 + random(i + 10) ** 3 * 2;
    matrix.compose(new Vector3(x, r * 0.3, z), new Quaternion(), new Vector3(r, r * 0.65, r * 0.8));
    rocks.setMatrixAt(i, matrix);
  }
  rocks.castShadow = true;
  group.add(rocks);
  const walk = apolloSuit.animations.find(clip => clip.name === 'walk');
  const crew = [
    [[8, 4], [10, 4], [11.5, 4.7], [10.4, 5.2], [8.2, 5.1]],
    [[7.4, 6.8], [6.4, 6.3], [5.9, 4.9], [7.1, 4.4]],
  ].map((points) => {
    const model = apolloSuit.scene.clone(true);
    model.visible = false;
    const mixer = new AnimationMixer(model);
    mixer.clipAction(walk).play();
    const path = new CatmullRomCurve3(points.map(([x, z]) => new Vector3(x, .005, z)), true);
    group.add(model);
    return { model, mixer, path, length: path.getLength() };
  });
  const explorer = crew[0].model;
  const helmet = explorer.getObjectByName('helmet');
  const heading = new Vector3();
  const flag = new Group();
  const pole = new Mesh(new CylinderGeometry(0.026, 0.026, 2.5, 8), white);
  pole.position.y = 1.25;
  flag.add(pole);
  const flagCanvas = document.createElement('canvas');
  flagCanvas.width = 380; flagCanvas.height = 200;
  const c = flagCanvas.getContext('2d');
  for (let i = 0; i < 13; i++) {
    c.fillStyle = i % 2 ? '#f8f5e9' : '#af2f3d';
    c.fillRect(0, i * 200 / 13, 380, 200 / 13 + 1);
  }
  c.fillStyle = '#263765'; c.fillRect(0, 0, 152, 108);
  c.fillStyle = '#f8f5e9';
  for (let row = 0; row < 9; row++) for (let col = 0; col < (row % 2 ? 5 : 6); col++) {
    c.fillRect(9 + col * 25 + (row % 2 ? 12 : 0), 8 + row * 11, 4, 4);
  }
  const fabric = new Mesh(new PlaneGeometry(1.4, 0.74), new MeshStandardMaterial({ map: new CanvasTexture(flagCanvas), side: 2, roughness: 1 }));
  fabric.position.set(0.72, 2.08, 0);
  flag.add(fabric);
  flag.position.set(11, 0, 6);
  group.add(flag);
  group.visible = false;
  let lastStep;
  return {
    group, explorer, helmet, background: marsSky.scene,
    get marsAir() { return marsAir; },
    update(state, halfHeight, time) {
      const moon = ['moonLanding', 'moonSurface', 'rendezvous'].includes(state.kind);
      const mars = ['marsLanding', 'marsSurface'].includes(state.kind);
      const landing = state.kind === 'moonLanding' || state.kind === 'marsLanding';
      const height = landing ? Math.max(0, state.altitude - 0.004) * 1000
        : state.kind === 'rendezvous' ? state.altitude * 1000 : 0;
      marsAir = mars ? 1 - MathUtils.smoothstep(height, 500, 25000) : 0;
      marsSky.material.uniforms.opacity.value = marsAir;
      group.visible = (moon || mars) && height < 2000;
      if (!group.visible) {
        lastStep = undefined;
        return false;
      }
      ground.visible = !mars;
      marsTerrain.visible = mars;
      rockFinish.color.setHex(mars ? 0x8c5d48 : 0x77756e);
      group.position.y = -halfHeight - height;
      flag.visible = state.kind === 'moonSurface';
      const walkTime = time * lunarPace;
      for (const [i, { model, mixer, path, length }] of crew.entries()) {
        model.visible = flag.visible;
        if (!model.visible) continue;
        const distance = (walkTime * apolloSuit.walkSpeed / length) % 1;
        path.getPointAt(distance, model.position);
        path.getTangentAt(distance, heading);
        model.rotation.y = Math.atan2(heading.x, heading.z);
        mixer.setTime(walkTime + i * walk.duration / 3);
      }
      if (!flag.visible) {
        lastStep = undefined;
        return false;
      }
      const step = Math.floor(2 * walkTime / walk.duration);
      const contact = lastStep !== undefined && step !== lastStep;
      lastStep = step;
      return contact;
    },
  };
}
