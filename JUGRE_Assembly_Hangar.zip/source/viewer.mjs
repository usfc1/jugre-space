import {
  ACESFilmicToneMapping, AnimationMixer, Box3, CanvasTexture, CatmullRomCurve3, Color, DirectionalLight, Fog,
  Group, HemisphereLight, MathUtils, Mesh, MeshBasicMaterial, PCFShadowMap, PerspectiveCamera, PlaneGeometry,
  PMREMGenerator, Scene, SRGBColorSpace, Vector3, WebGLRenderer,
} from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { setupBuilder } from './builder.mjs';
import { prepareParts } from './assembly.mjs';
import { clipPose } from './payload-preview.mjs';
import { setupReadyRockets } from './ready-rockets.mjs';
import { kennedyCameras } from './kennedy-layout.mjs';
import { setupLaunchView } from './launch-view.mjs';
import { setupFlightView } from './flight-view.mjs';
import { setupHangarAudio } from './audio-view.mjs';

const storageKey = 'jugre.assembly-hangar.wordmark';
const viewModes = {
  overview: { position: [-8.65, 5.3, 15.25], target: [0.05, 4.25, -7], label: 'Общий вид' },
  rocket: { position: [-4.7, 4.05, 9.9], target: [-0.45, 2.85, -4.42], label: 'Сборка ракеты' },
  ready: { position: [1.8, 5.1, 12.9], target: [0, 3.7, -4.42], label: 'Готовые ракеты' },
  launch: { ...kennedyCameras.pad, label: 'Стартовая площадка' },
  crew: { position: [-5.4, 2.1, 9.75], target: [-5.4, .9, 3.65], label: 'Экипаж' },
};

function storedWordmark(defaultText) {
  try {
    return localStorage.getItem(storageKey) || defaultText;
  } catch {
    return defaultText;
  }
}

function updateWordmark(root, defaultText) {
  const baked = [...root.children];
  const canvas = document.createElement('canvas');
  canvas.width = 1600;
  canvas.height = 408;
  const context = canvas.getContext('2d');
  const texture = new CanvasTexture(canvas);
  texture.colorSpace = SRGBColorSpace;
  const overlay = new Mesh(new PlaneGeometry(5.7, 1.45), new MeshBasicMaterial({
    map: texture, transparent: true, depthWrite: false, toneMapped: false,
  }));
  overlay.position.z = 0.016;
  root.add(overlay);
  const field = document.querySelector('#wordmark');
  function apply(text) {
    const isDefault = text === defaultText;
    for (const item of baked) item.visible = isDefault;
    overlay.visible = !isDefault;
    root.userData.text = text;
    if (isDefault) return;
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.font = '800 294px "Segoe UI", Arial, sans-serif';
    context.textAlign = 'center';
    context.textBaseline = 'middle';
    context.fillStyle = '#e9e2cf';
    context.fillText(text, 800, 204, 1550);
    texture.needsUpdate = true;
  }

  const dialog = document.querySelector('#branding');
  const feedback = document.querySelector('#feedback');
  let text = storedWordmark(defaultText);
  apply(text);
  document.querySelector('#edit-brand').addEventListener('click', () => {
    field.value = text;
    dialog.showModal();
    field.select();
  });
  field.addEventListener('input', () => apply(field.value.trim() || defaultText));
  document.querySelector('#reset-brand').addEventListener('click', () => {
    field.value = defaultText;
    apply(defaultText);
    field.focus();
  });
  document.querySelector('#cancel-brand').addEventListener('click', () => dialog.close());
  document.querySelector('#brand-form').addEventListener('submit', (event) => {
    event.preventDefault();
    text = field.value.trim() || defaultText;
    try {
      localStorage.setItem(storageKey, text);
      feedback.textContent = 'Вывеска сохранена';
    } catch {
      feedback.textContent = 'Вывеска обновлена для этого просмотра';
    }
    dialog.close();
  });
  dialog.addEventListener('close', () => apply(text));
}

function mountScientist(asset, spec, speeds) {
  const route = new CatmullRomCurve3(spec.route.points.map(([x, z]) => new Vector3(x, 0.021, z)), true);
  route.arcLengthDivisions = 500;
  const length = route.getLength();
  const character = asset.scene;
  const mixer = new AnimationMixer(character);
  const actions = Object.fromEntries(asset.animations.map((clip) => [clip.name, mixer.clipAction(clip)]));
  const position = new Vector3();
  const heading = new Vector3();
  let distance = spec.route.start * length;
  let current = 'walk';
  let speed = speeds.walk;
  actions.walk.play();
  actions.walk.time = spec.route.start * 1.14;
  mixer.update(0);

  return {
    character,
    update(dt, elapsed) {
      const runOffset = spec.route.runOffset;
      const gait = runOffset !== null && (elapsed + runOffset) % 18 < 6 ? 'run' : 'walk';
      if (gait !== current) {
        actions[current].fadeOut(0.21);
        actions[gait].reset().fadeIn(0.21).play();
        current = gait;
      }
      speed = MathUtils.damp(speed, speeds[current], 12, dt);
      distance = (distance + speed * dt) % length;
      route.getPointAt(distance / length, position);
      route.getTangentAt(distance / length, heading);
      character.position.copy(position);
      character.rotation.y = Math.atan2(heading.x, heading.z);
      mixer.update(dt);
    },
  };
}

function lightScene(scene, renderer) {
  const room = new RoomEnvironment();
  const pmrem = new PMREMGenerator(renderer);
  const reflection = pmrem.fromScene(room, 0.03);
  scene.environment = reflection.texture;
  scene.environmentIntensity = 0.52;
  pmrem.dispose();
  room.dispose();
  scene.add(new HemisphereLight(0xe5f1ff, 0xa49b87, 1.75));
  const light = (color, intensity, position) => {
    const lamp = new DirectionalLight(color, intensity);
    lamp.position.set(...position);
    lamp.target.position.set(0, 0, -4);
    scene.add(lamp, lamp.target);
    return lamp;
  };
  const key = light(0xffe8cf, 2.25, [-5.5, 9.6, 3.3]);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -17;
  key.shadow.camera.right = 17;
  key.shadow.camera.top = 15;
  key.shadow.camera.bottom = -15;
  key.shadow.camera.near = 0.1;
  key.shadow.camera.far = 38;
  key.shadow.normalBias = 0.028;
  key.shadow.bias = -0.00015;
  key.shadow.radius = 3.5;
  light(0xb4dfff, 1.06, [7, 8.1, -12.8]);
  light(0xd6e8ff, 0.48, [1, 3.8, 13]);
}

async function start() {
  const { hangar, launchComplex, scientists, manifest, catalog } = window.hangarData;
  const canvas = document.querySelector('canvas');
  const viewport = document.querySelector('#viewport');
  const renderer = new WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = PCFShadowMap;
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.98;
  const scene = new Scene();
  scene.background = new Color(0x192633);
  scene.fog = new Fog(0x596d7c, 24, 58);
  const camera = new PerspectiveCamera(48, 1, 0.08, 90);
  const controls = new OrbitControls(camera, canvas);
  controls.enablePan = false;
  controls.enableDamping = true;
  controls.dampingFactor = 0.13;
  controls.zoomSpeed = 0.65;
  lightScene(scene, renderer);

  const loader = new GLTFLoader();
  const decode = (bytes) => Uint8Array.fromBase64
    ? Uint8Array.fromBase64(bytes)
    : Uint8Array.from(atob(bytes), (char) => char.charCodeAt(0));
  const parse = (bytes) => loader.parseAsync(decode(bytes).buffer, '');
  const modelFiles = Object.entries(catalog);
  const partClips = new Map();
  const [asset, people, partModels, complex, suits] = await Promise.all([
    parse(hangar), Promise.all(scientists.map(parse)),
    Promise.all(modelFiles.map(async ([id, { glb, clip }]) => {
      const { scene: model, animations } = await parse(glb);
      if (clip) {
        const animation = animations.find(({ name }) => name === clip);
        if (!animation) throw new Error(`Missing ${clip} in ${id}`);
        partClips.set(id, animation);
        clipPose(model, animation)(0);
      }
      return [id, model];
    })),
    parse(launchComplex),
    Promise.all(manifest.flight.astronauts.map(async (spec) => {
      const model = await parse(document.getElementById(`flight-data-${spec.model}`).textContent);
      model.scene.traverse((item) => {
        if (!item.isMesh) return;
        item.castShadow = item.receiveShadow = true;
        for (const material of [item.material].flat()) {
          material.envMap = scene.environment;
          material.envMapIntensity = .55;
        }
      });
      return { ...spec, ...model };
    })),
  ]);
  delete window.hangarData;
  let brand;
  let bakedRocket;
  const trestles = [];
  asset.scene.traverse((item) => {
    const id = item.userData.partId;
    if (id === manifest.wordmark.node) brand = item;
    if (id === manifest.hangar.exampleAssembly) bakedRocket = item;
    if (id?.startsWith('assembly_hangar.workstations.stand_') && item.parent?.userData.partId === 'assembly_hangar.workstations') {
      trestles.push(item);
    }
    if (!item.isMesh) return;
    const group = item.parent?.userData.partId ?? '';
    item.receiveShadow = true;
    item.castShadow = !/floor|roof|wall|us_flag|brand_frame/.test(group);
  });
  if (!brand || !bakedRocket) throw new Error('An expected hangar node is missing');
  bakedRocket.removeFromParent();
  scene.add(asset.scene);
  updateWordmark(brand, manifest.wordmark.default);
  const crew = people.map((npc, index) => {
    npc.scene.traverse((item) => {
      if (item.isMesh) item.castShadow = item.receiveShadow = true;
    });
    return mountScientist(npc, manifest.scientists[index], manifest.locomotionMps);
  });
  for (const person of crew) scene.add(person.character);
  const suitDisplay = new Group();
  suitDisplay.visible = false;
  scene.add(suitDisplay);
  const suitMixers = suits.map((suit, i) => {
    const actor = suit.scene.clone(true);
    actor.position.set(-5.4 + (i - (suits.length - 1) / 2) * 1.35, .021, 3.65);
    actor.rotation.y = (1.5 - i) * .19;
    suitDisplay.add(actor);
    const mixer = new AnimationMixer(actor);
    mixer.clipAction(suit.animations.find(clip => clip.name === 'idle')).play();
    return mixer;
  });

  let transition;
  let currentView;
  let paused = false;
  const occupiedTrestles = new Set();
  function updateTrestles() {
    for (const trestle of trestles) {
      trestle.visible = currentView !== 'ready' && !occupiedTrestles.has(trestle);
    }
  }
  const readyRockets = setupReadyRockets({
    scene, rockets: manifest.readyRockets, decode,
    load: (bytes) => loader.parseAsync(bytes.buffer, ''),
  });
  const specs = prepareParts(Object.fromEntries(modelFiles.map(([id, { glb, ...spec }]) => [id, spec])));
  const builder = setupBuilder({
    scene, camera, controls, canvas, specs, models: new Map(partModels), clips: partClips,
    onGrip() { transition = undefined; },
    onLayout(pieces) {
      const bays = [...pieces.values()].filter((piece) => piece.spec.system === 'bay')
        .map((piece) => new Box3().setFromObject(piece.visual));
      occupiedTrestles.clear();
      for (const trestle of trestles) {
        const bounds = new Box3().setFromObject(trestle);
        if (bays.some((bay) => bounds.intersectsBox(bay))) occupiedTrestles.add(trestle);
      }
      updateTrestles();
    },
    onInspect(piece, kind, releaseM = 0) {
      const target = piece.object.localToWorld(kind === 'crew' ? new Vector3(0, 0.72, 0)
        : new Vector3(-releaseM * 0.62, 2.83, 0));
      const position = target.clone().add(kind === 'crew' ? new Vector3(3.45, 1.25, 4.0)
        : new Vector3(4.45, 2.8, 5.55));
      transition = { start: performance.now(), from: camera.position.clone(), look: controls.target.clone(), position, target };
    },
    onPreset() { selectView('rocket', true); },
  });
  const launch = setupLaunchView({
    complex: complex.scene, rockets: manifest.readyRockets, decode, loader, environment: scene.environment,
    customCraft: () => builder.snapshotCraft(), anisotropy: Math.min(8, renderer.capabilities.getMaxAnisotropy()),
    fitCamera(position, target) {
      camera.position.set(...position);
      controls.target.set(...target);
      controls.update();
    },
  });
  const outdoorRoutes = [
    [[-162, 117], [-150, 117], [-150, 106], [-162, 106]],
    [[134, 17], [144, 17], [144, 6], [134, 6]],
    [[-38, 31], [-28, 31], [-28, 39], [-38, 39]],
    [[-197, 118], [-180, 118], [-180, 125], [-197, 125]],
  ];
  const outdoorCrew = people.map((npc, index) => mountScientist({
    scene: npc.scene.clone(true), animations: npc.animations,
  }, { route: { start: index * 0.14, runOffset: null, points: outdoorRoutes[index] } }, manifest.locomotionMps));
  for (const person of outdoorCrew) {
    person.update(0, 0);
    launch.scene.add(person.character);
  }
  const audio = setupHangarAudio(decode);
  const flight = setupFlightView({
    launch, camera, controls, loader, decode, audio, suits: Object.fromEntries(suits.map(suit => [suit.id, suit])),
    textures: window.flightTextures,
    onStart(title) {
      transition = undefined;
      document.querySelector('.crew-state').hidden = true;
      document.querySelector('.hint').textContent = 'Мышь — обзор 360° · W/S — наклон · A/D — крен · Q/E — курс';
      document.querySelector('#launch-panel').hidden = true;
      const area = document.querySelector('#work-area');
      area.classList.remove('launching');
      area.classList.add('flying');
      document.querySelectorAll('nav button').forEach((button) => { button.disabled = true; });
      document.querySelector('h1').textContent = title;
      document.querySelector('#current-view').textContent = 'Полёт';
      document.querySelector('#location-tag').textContent = 'Кеннеди / LC-39A';
    },
    onStop() {
      document.querySelector('.crew-state').hidden = false;
      document.querySelector('.hint').textContent = 'Пустая область — поворот камеры · Колесо или щипок — масштаб';
      document.querySelector('#work-area').classList.remove('flying');
      document.querySelectorAll('nav button').forEach((button) => { button.disabled = false; });
      selectView('launch', true);
    },
  });
  delete window.flightTextures;

  function resize() {
    const width = viewport.clientWidth;
    const height = viewport.clientHeight;
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    const framing = currentView === 'rocket' || currentView === 'ready' ? 1.35 : 1;
    const baseFov = flight.active ? 24 : currentView === 'launch' ? 23 : 24;
    camera.fov = MathUtils.radToDeg(2 * Math.atan(Math.tan(MathUtils.degToRad(baseFov)) * Math.max(1, framing / camera.aspect)));
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(viewport);
  resize();

  function selectView(id, immediate = false) {
    const view = viewModes[id];
    const position = new Vector3(...view.position);
    const target = new Vector3(...view.target);
    currentView = id;
    suitDisplay.visible = id === 'crew';
    for (const person of crew) person.character.visible = !suitDisplay.visible;
    updateCrewStatus();
    const building = id === 'rocket';
    const ready = id === 'ready';
    const outside = id === 'launch';
    const atStand = building || ready;
    builder.setEnabled(building);
    builder.setCraftVisible(!ready);
    readyRockets.setEnabled(ready);
    updateTrestles();
    controls.minDistance = outside ? 35 : 2.8;
    controls.maxDistance = outside ? 24000 : id === 'overview' ? 24.6 : atStand ? 21 : 12.7;
    controls.minAzimuthAngle = atStand || outside ? -Infinity : -0.66;
    controls.maxAzimuthAngle = atStand || outside ? Infinity : 0.66;
    controls.minPolarAngle = outside ? 0.03 : atStand ? 1.04 : 1.37;
    controls.maxPolarAngle = outside ? 1.51 : atStand ? 1.68 : 1.64;
    camera.far = outside ? 65000 : 90;
    camera.near = outside ? 0.8 : 0.08;
    controls.enablePan = outside;
    launch.setEnabled(outside);
    document.querySelector('h1').textContent = outside ? 'Космический центр Кеннеди' : 'Сборочный ангар';
    document.querySelector('#location-tag').textContent = outside ? 'Флорида / LC-39A' : 'Цех 01';
    document.querySelector('#edit-brand').hidden = outside;
    resize();
    if (immediate || outside || camera.position.length() > 50) {
      transition = undefined;
      camera.position.copy(position);
      controls.target.copy(target);
      controls.update();
    } else {
      transition = { start: performance.now(), from: camera.position.clone(), look: controls.target.clone(), position, target };
    }
    document.querySelectorAll('[data-view]').forEach((button) =>
      button.setAttribute('aria-pressed', String(button.dataset.view === id)));
    document.querySelector('#current-view').textContent = view.label;
  }
  document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => selectView(button.dataset.view)));
  controls.addEventListener('start', () => { transition = undefined; });
  selectView(location.hash === '#launch' ? 'launch' : 'rocket', true);
  resize();

  const offset = new Vector3();
  function keepCameraInside() {
    offset.copy(camera.position).sub(controls.target);
    let limit = 1;
    for (const [axis, lower, upper] of [['x', -14.3, 14.3], ['y', 0.85, 10.25], ['z', -15.3, 16.6]]) {
      if (camera.position[axis] > upper) limit = Math.min(limit, (upper - controls.target[axis]) / offset[axis]);
      if (camera.position[axis] < lower) limit = Math.min(limit, (lower - controls.target[axis]) / offset[axis]);
    }
    if (limit < 1) camera.position.copy(controls.target).addScaledVector(offset, limit);
  }

  function updateCrewStatus() {
    document.querySelector('#crew-status').textContent = paused ? 'Движение на паузе'
      : currentView === 'crew' ? suits.map(suit => suit.title).join(' · ') : '04 сотрудника';
  }
  const play = document.querySelector('#pause');
  play.addEventListener('click', () => {
    paused = !paused;
    play.setAttribute('aria-pressed', String(paused));
    play.querySelector('span').textContent = paused ? 'Продолжить' : 'Пауза';
    updateCrewStatus();
    document.querySelector('#activity').classList.toggle('paused', paused);
  });

  let last = performance.now();
  let elapsed = 0;
  document.addEventListener('visibilitychange', () => { last = performance.now(); });
  for (const person of crew) person.update(0, elapsed);
  renderer.setAnimationLoop((now) => {
    const wallDt = Math.max((now - last) / 1000, 0);
    const dt = Math.min(wallDt, 0.08);
    last = now;
    if (!paused) {
      elapsed += dt;
      for (const person of crew) person.update(dt, elapsed);
      if (suitDisplay.visible) for (const mixer of suitMixers) mixer.update(dt);
      if (currentView === 'launch') for (const person of outdoorCrew) person.update(dt, elapsed);
    }
    if (transition) {
      const p = Math.min((now - transition.start) / 560, 1);
      const eased = p * p * (3 - 2 * p);
      camera.position.lerpVectors(transition.from, transition.position, eased);
      controls.target.lerpVectors(transition.look, transition.target, eased);
      if (p === 1) transition = undefined;
    }
    controls.update();
    if (currentView === 'rocket' || currentView === 'ready') keepCameraInside();
    camera.updateMatrixWorld();
    builder.update(dt);
    launch.update(dt);
    launch.updateLabels(camera);
    flight.update(dt);
    audio.tick();
    if (!flight.render(renderer)) renderer.render(currentView === 'launch' ? launch.scene : scene, camera);
  });
  document.querySelector('#loading').hidden = true;
  document.querySelectorAll('nav button, #pause, #edit-brand').forEach((button) => { button.disabled = false; });
}

start().catch((error) => {
  console.error(error);
  document.querySelector('#loading').textContent = 'Не удалось открыть 3D-сцену. Перезагрузите страницу в браузере с поддержкой WebGL.';
});
