import { BoxGeometry, CylinderGeometry, Group, Mesh, MeshStandardMaterial, Raycaster, Vector3 } from 'three';

const storageKey = 'jugre.assembly-hangar.ready-rocket.v1';
const center = new Vector3(0, 2.35, -4.42);
const upright = new Vector3(0, 1, 0);
const lengthOnStand = 16.5;
const metal = new MeshStandardMaterial({ color: 0x33434d, metalness: 0.28, roughness: 0.69 });
const safety = new MeshStandardMaterial({ color: 0xcd852e, metalness: 0.18, roughness: 0.65 });
const meters = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });

function fitOnStand(model, bounds) {
  const { min, max } = bounds;
  const scale = lengthOnStand / (max[1] - min[1]);
  const localCenter = new Vector3(...min).add(new Vector3(...max)).multiplyScalar(0.5);
  model.rotation.z = -Math.PI / 2;
  model.scale.setScalar(scale);
  model.position.copy(center).sub(localCenter.applyQuaternion(model.quaternion).multiplyScalar(scale));
  model.updateMatrixWorld(true);
  model.traverse((item) => {
    if (item.isMesh) item.castShadow = item.receiveShadow = true;
  });

  const group = new Group();
  group.add(model);
  const box = (material, size, position) => {
    const part = new Mesh(new BoxGeometry(...size), material);
    part.position.set(...position);
    part.castShadow = part.receiveShadow = true;
    group.add(part);
  };
  const ray = new Raycaster();
  for (const x of [-4.7, 1.95]) {
    ray.set(new Vector3(x, 0.1, center.z), upright);
    const contact = ray.intersectObject(model, true)[0]?.point.y ?? center.y - 0.6;
    box(metal, [1.3, 0.16, 2.5], [x, 0.12, center.z]);
    box(metal, [0.68, 0.16, 0.73], [x, contact - 0.08, center.z]);
    for (const side of [-1, 1]) {
      const base = new Vector3(x, 0.2, center.z + side * 1.04);
      const pad = new Vector3(x, contact - 0.16, center.z + side * 0.26);
      const direction = pad.clone().sub(base);
      const brace = new Mesh(new CylinderGeometry(0.104, 0.132, direction.length(), 8), safety);
      brace.position.copy(base).lerp(pad, 0.5);
      brace.quaternion.setFromUnitVectors(upright, direction.normalize());
      brace.castShadow = brace.receiveShadow = true;
      group.add(brace);
    }
  }
  return group;
}

export function setupReadyRockets({ scene, rockets, decode, load }) {
  const area = document.querySelector('#work-area');
  const panel = document.querySelector('#ready-rockets');
  const list = document.querySelector('#ready-list');
  const vehicle = document.querySelector('#ready-vehicle');
  const payload = document.querySelector('#ready-payload');
  const length = document.querySelector('#ready-length');
  const download = document.querySelector('#ready-download');
  const status = document.querySelector('#ready-status');
  const cache = new Map();
  let selected = rockets[0];
  let displayed;
  let visible = false;
  let request = 0;
  try {
    selected = rockets.find(({ id }) => id === localStorage.getItem(storageKey)) ?? selected;
  } catch { /* Start with Apollo 11 when storage is unavailable. */ }

  const bytesFor = (id) => decode(document.getElementById(`rocket-data-${id}`).textContent);

  function loadOnce(spec) {
    if (!cache.has(spec.id)) {
      const loading = load(bytesFor(spec.id)).then(({ scene: model }) => fitOnStand(model, spec.bounds))
        .catch((error) => {
          cache.delete(spec.id);
          throw error;
        });
      cache.set(spec.id, loading);
    }
    return cache.get(spec.id);
  }

  async function select(spec) {
    selected = spec;
    const token = ++request;
    const height = spec.bounds.max[1] - spec.bounds.min[1];
    for (const button of list.children) button.setAttribute('aria-pressed', String(button.dataset.rocket === spec.id));
    vehicle.textContent = spec.launcher;
    payload.textContent = spec.payload;
    length.textContent = `${meters.format(height)} м`;
    if (displayed?.id === spec.id) {
      status.textContent = 'На стапеле';
      download.disabled = false;
      return;
    }
    displayed?.group.removeFromParent();
    displayed = undefined;
    download.disabled = true;
    status.textContent = 'Загрузка сборки…';
    try {
      const group = await loadOnce(spec);
      if (token !== request) return;
      displayed = { id: spec.id, group };
      group.visible = visible;
      scene.add(group);
      status.textContent = 'На стапеле';
      download.disabled = false;
      try { localStorage.setItem(storageKey, spec.id); } catch { /* The current selection is still available. */ }
    } catch (error) {
      if (token !== request) return;
      console.error(error);
      status.textContent = 'Модель не загрузилась. Выберите её ещё раз.';
    }
  }

  for (const [index, spec] of rockets.entries()) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'ready-card';
    button.dataset.rocket = spec.id;
    button.setAttribute('aria-pressed', 'false');
    const number = document.createElement('span');
    number.className = 'ready-number';
    number.textContent = String(index + 1).padStart(2, '0');
    const info = document.createElement('span');
    const name = document.createElement('strong');
    name.textContent = spec.name;
    const launcher = document.createElement('small');
    launcher.textContent = spec.launcher;
    info.append(name, launcher);
    button.append(number, info);
    button.addEventListener('click', () => select(spec));
    list.append(button);
  }
  download.addEventListener('click', () => {
    const url = URL.createObjectURL(new Blob([bytesFor(selected.id)], { type: 'model/gltf-binary' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = selected.file.split('/').at(-1);
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  });
  return {
    setEnabled(active) {
      const entering = active && !visible;
      visible = active;
      area.classList.toggle('ready', active);
      panel.hidden = !active;
      if (displayed) displayed.group.visible = active;
      if (entering) select(selected);
    },
  };
}
