import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { setTimeout as wait } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { Box3, Scene } from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { seal } from '../../original_parts/source/geometry.mjs';
import { buildHangar } from './hangar.mjs';
import { buildScientist, scientistStyles } from './scientist.mjs';
import { prepareParts } from './assembly.mjs';
import { buildBay, buildCrew, cargoIds, packedCargo } from './cargo.mjs';
import { collectReadyRockets } from './ready-rockets-build.mjs';
import { buildLaunchComplex } from './launch-complex.mjs';
import { embedKennedyTextures } from './kennedy-textures-build.mjs';
import { kennedySites, kennedyTiles } from './kennedy-layout.mjs';
import { collectFlightAssets } from './flight-assets-build.mjs';
import { radioLines } from './mission-radio.mjs';

globalThis.FileReader ??= class {
  async readAsArrayBuffer(blob) {
    this.result = await blob.arrayBuffer();
    this.onloadend?.();
  }
};

const routes = [
  { start: 0.03, runOffset: null, points: [[-7, 3], [0, 2.8], [6.8, 3.1], [7, 8.7], [-6.9, 8.7]] },
  { start: 0.2, runOffset: null, points: [[-7, -11.2], [0, -11.1], [6.6, -10.9], [6.4, -14.6], [-6.8, -14.5]] },
  { start: 0.042, runOffset: 3, points: [[-9.45, 5.8], [-9.55, -2], [-10.55, -9.5], [-12.25, -8], [-12.12, 7.4], [-11.5, 9.8]] },
  { start: 0.62, runOffset: 12, points: [[9.25, -7.6], [9.25, 0], [9.3, 7.5], [11.85, 9], [12, -7.6], [10.9, -10.2]] },
];
const exporter = new GLTFExporter();
const manifest = {
  version: 1,
  name: 'JUGRE Assembly Hangar',
  units: 'meter',
  up: '+Y',
  visitorForward: '+Z',
  hangar: { file: 'models/assembly_hangar.glb', exampleAssembly: 'assembly_hangar.example_rocket' },
  wordmark: { node: 'assembly_hangar.brand_frame.hangar_brand', default: 'JUGRE' },
  locomotionMps: { walk: 1.3, run: 2.9 },
  scientists: [],
};

async function exportGLB(root, file, clips = [], transform = null) {
  const scene = new Scene();
  scene.name = root.name;
  scene.add(root);
  const exported = Buffer.from(await exporter.parseAsync(scene, { binary: true, trs: true, animations: clips }));
  const data = transform ? await transform(exported) : exported;
  if (data.toString('ascii', 0, 4) !== 'glTF' || data.readUInt32LE(8) !== data.length) {
    throw new Error(`Invalid GLB header for ${file}`);
  }
  await writeFile(new URL(`../${file}`, import.meta.url), data);
  return data.toString('base64');
}

await mkdir(new URL('../models/', import.meta.url), { recursive: true });
const partsFolder = new URL('../../original_parts/', import.meta.url);
const { parts } = JSON.parse(await readFile(new URL('manifest.json', partsFolder), 'utf8'));
const catalog = Object.fromEntries(await Promise.all(Object.entries(parts).map(async ([id, spec]) => {
  const { code, name, group, mounts, stats, dimensionsM } = spec;
  const model = await readFile(new URL(spec.file, partsFolder));
  return [id, { code, name: name.ru, group, mounts, stats, dimensionsM, glb: model.toString('base64') }];
})));
const command = catalog.pb_1_strizh;
Object.assign(command, { name: 'Блок управления «Стриж»', group: 'command', detail: 'Без экипажа · Ø 1,25 м' });
await mkdir(new URL('../models/payload/', import.meta.url), { recursive: true });
manifest.payloadParts = {};
for (const asset of [buildBay(), await buildCrew(catalog.pk_2_kontur)]) {
  const file = `models/payload/${asset.root.name}.glb`;
  const glb = await exportGLB(asset.root, file, asset.clips);
  catalog[asset.root.name] = { ...asset.spec, glb };
  const { glb: embedded, ...spec } = asset.spec;
  manifest.payloadParts[asset.root.name] = { file, ...spec };
}
const kit = new URL('../../constructor_kit/', import.meta.url);
const kitParts = JSON.parse(await readFile(new URL('manifest.json', kit), 'utf8')).parts;
const cargoNames = [
  ['МК', 'Спутник «Маяк-К»'], ['МС', 'Спутник «Маяк-С»'],
  ['Б-4', 'Ровер «Бархан-4»'], ['Б-6', 'Ровер «Бархан-6»'],
];
for (const [index, id] of cargoIds.entries()) {
  const part = kitParts[id];
  const spec = packedCargo(id, part, ...cargoNames[index]);
  const bytes = await readFile(new URL(part.file, kit));
  const file = `models/payload/${id}.glb`;
  await writeFile(new URL(`../${file}`, import.meta.url), bytes);
  catalog[id] = { ...spec, glb: bytes.toString('base64') };
  manifest.payloadParts[id] = { file, ...spec };
}
const { root, addDemo } = await buildHangar();
seal(root);
await addDemo(prepareParts(parts));
const bounds = new Box3().setFromObject(root, true);
manifest.hangar.bounds = { min: bounds.min.toArray(), max: bounds.max.toArray() };
const hangar = await exportGLB(root, manifest.hangar.file);
const launchRoot = buildLaunchComplex();
manifest.launchComplex = {
  file: 'models/jugre_launch_complex.glb', units: 'meter', rocketMount: 'jugre_launch_complex.rocket_mount',
  rocketTranslation: [0, 9.08, 0], towerHeightM: 134.1,
  name: 'Kennedy Space Center', anchor: 'LC-39A', shoreline: 'east',
  landmarks: kennedySites, aerialTiles: kennedyTiles,
};
const launchComplex = await exportGLB(launchRoot, manifest.launchComplex.file, [], embedKennedyTextures);
const scientists = [];
for (const [index, style] of scientistStyles.entries()) {
  const { root: character, clips } = buildScientist(style);
  const file = `models/scientist_${style.id}.glb`;
  scientists.push(await exportGLB(seal(character), file, clips));
  manifest.scientists.push({ file, clips: clips.map((clip) => clip.name), route: routes[index] });
}
const readyRockets = await collectReadyRockets();
manifest.readyRockets = readyRockets.map(({ spec }) => spec);
const flight = await collectFlightAssets();
const recordings = await Promise.all(Object.entries(radioLines).map(async ([id, line]) => {
  const file = `assets/audio/radio/${id}.mp3`;
  const audio = await readFile(new URL(`../${file}`, import.meta.url)).catch(error => {
    if (error.code !== 'ENOENT') throw error;
    console.warn(`Missing radio recording (subtitle only): ${file}`);
    return null;
  });
  return { id, file, ...line, audio };
}));
manifest.flight = { launchLocation: { name: 'Космический центр Кеннеди · LC-39A', latitude: 28.6084, longitude: -80.6042 },
  mode: 'educational', missions: flight.missions, astronauts: flight.astronauts,
  models: flight.models.map(({ id, file }) => ({ id, file })) };
manifest.audio = {
  voices: 'en', subtitles: 'ru',
  recordings: recordings.map(({ audio, ...clip }) => ({ ...clip, available: Boolean(audio?.length) })),
};
await writeFile(new URL('../manifest.json', import.meta.url), `${JSON.stringify(manifest, null, 2)}\n`);
const [template, bundle, license] = await Promise.all([
  readFile(new URL('./viewer.html', import.meta.url), 'utf8'),
  build({
    entryPoints: [fileURLToPath(new URL('./viewer.mjs', import.meta.url))],
    bundle: true, write: false, minify: true, format: 'iife', target: 'es2022',
  }),
  readFile(new URL('../LICENSE', import.meta.resolve('three')), 'utf8'),
]);
const html = template
  .replace('/* ASSET_DATA */', () => `window.hangarData = ${JSON.stringify({ hangar, launchComplex, scientists, manifest, catalog })};`)
  .replace('<!-- READY_ROCKET_DATA -->', () => readyRockets.map(({ spec, glb }) =>
    `<script type="application/octet-stream" id="rocket-data-${spec.id}">${glb}</script>`).join('\n'))
  .replace('<!-- FLIGHT_DATA -->', () => `<script>window.flightTextures=${JSON.stringify(flight.textures)};</script>\n`
    + flight.models.map(({ id, glb }) => `<script type="application/octet-stream" id="flight-data-${id}">${glb}</script>`).join('\n'))
  .replace('<!-- RADIO_DATA -->', () => recordings.filter(({ audio }) => audio?.length).map(({ id, audio }) =>
    `<script type="application/octet-stream" id="audio-data-${id}">${audio.toString('base64')}</script>`).join('\n'))
  .replace('/* VIEWER_SCRIPT */', () => bundle.outputFiles[0].text.replaceAll('</script', '<\\/script'))
  .replace('<!-- THREE_LICENSE -->', () => `<!-- Three.js\n${license.trim()}\n-->`);
const stagedViewer = new URL(`../.index-${process.pid}.tmp`, import.meta.url);
try {
  await writeFile(stagedViewer, html);
  for (let attempt = 0; ; attempt++) {
    try {
      await rename(stagedViewer, new URL('../index.html', import.meta.url));
      break;
    } catch (error) {
      if (attempt === 4 || !['EPERM', 'EBUSY', 'EACCES'].includes(error.code)) throw error;
      await wait(200 * 2 ** attempt);
    }
  }
} finally {
  await rm(stagedViewer, { force: true });
}
console.log(`Exported the assembly hangar, ${scientists.length} animated scientists, ${readyRockets.length} ready rockets and the offline viewer.`);
