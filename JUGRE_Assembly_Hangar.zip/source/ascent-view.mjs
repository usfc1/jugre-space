import { Matrix3, Matrix4, Mesh, PlaneGeometry, Scene, ShaderMaterial, Vector3, MathUtils } from 'three';
import { EARTH_RADIUS, launchUp, east } from './flight-missions.mjs';
import { kennedyTiles } from './kennedy-layout.mjs';

function localImagery(terrainMaps) {
  const tiles = kennedyTiles.filter(({ id }) => terrainMaps[id]);
  const sampler = (id) => `kennedy_${id}`;
  const uniforms = Object.fromEntries(tiles.map(({ id }) => [sampler(id), { value: terrainMaps[id] }]));
  const declarations = tiles.map(({ id }) => `uniform sampler2D ${sampler(id)};`).join('\n');
  const samples = tiles.map(({ id, bounds }, index) => {
    const [west, north, east, south] = bounds;
    return `{
      vec2 uv=(ground-vec2(${west}.0,${north}.0))/vec2(${east-west}.0,${south-north}.0);
      vec2 edge=min(uv,1.-uv);
      float inside=min(edge.x,edge.y);
      if(inside>0.) {
        vec3 tile=texture2D(${sampler(id)},uv).rgb;
        color=mix(color,tile,${index === 0 ? 'smoothstep(0.,.055,inside)*visibility' : 'visibility'});
      }
    }`;
  }).join('\n');
  return {
    uniforms,
    shader: `${declarations}
      vec3 applyKennedy(vec3 color,vec2 ground,float visibility){
        ${samples}
        return color;
      }`,
  };
}

// Camera-relative ray/sphere intersection gives a continuous horizon all the
// way from the launch coast to orbit, without giant low-altitude globe facets.
export function createAscentView(day, terrainMaps = {}) {
  const imagery = localImagery(terrainMaps);
  const scene = new Scene();
  const material = new ShaderMaterial({
    depthTest: false, depthWrite: false, transparent: true,
    uniforms: {
      ...imagery.uniforms,
      day: { value: day }, eye: { value: new Vector3() }, cameraBasis: { value: new Matrix3() },
      frame: { value: new Matrix3() },
      launchOffset: { value: new Vector3() }, east: { value: new Vector3() }, north: { value: new Vector3() },
      sun: { value: new Vector3() }, height: { value: 0 }, aspect: { value: 1 }, tanFov: { value: .445 },
      opacity: { value: 1 },
    },
    vertexShader: 'varying vec2 screen;void main(){screen=position.xy;gl_Position=vec4(position.xy,.999999,1.);}',
    fragmentShader: `
      varying vec2 screen;
      uniform sampler2D day;uniform vec3 eye;uniform mat3 cameraBasis;uniform mat3 frame;
      uniform vec3 launchOffset;uniform vec3 east;uniform vec3 north;uniform vec3 sun;
      uniform float height;uniform float aspect;uniform float tanFov;uniform float opacity;
      ${imagery.shader}
      const float R=6371.;const float PI=3.14159265359;
      float hash(vec3 p){p=fract(p*.1031);p+=dot(p,p.yzx+33.33);return fract((p.x+p.y)*p.z);}
      float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
        return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
          mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+1.),f.x),f.y),f.z);}
      float fbm(vec3 p){float f=0.,a=.55;for(int i=0;i<4;i++){f+=a*noise(p);p=p*2.13+vec3(3.4,7.2,1.8);a*=.48;}return f;}
      float hitSphere(vec3 ray,float shell){
        float b=dot(eye,ray)+(R+height)*ray.y;
        float c=(height-shell)*(2.*R+height+shell)+2.*(R+height)*eye.y+dot(eye,eye);
        float d=b*b-c;if(d<0.)return -1.;
        float farHit=-b+sqrt(d);
        if(farHit<=0.)return -1.;
        return c>0.?c/farHit:farHit;
      }
      vec3 sky(vec3 ray){float air=exp(-height/25.);float y=max(ray.y,0.);
        vec3 daylight=mix(vec3(.49,.69,.84),vec3(.055,.22,.50),pow(y,.36));
        vec3 color=mix(vec3(.001,.003,.009),daylight,air);
        float glow=pow(max(dot(ray,sun),0.),12.);color+=vec3(.32,.23,.11)*glow*air;
        color+=vec3(2.,1.8,1.5)*smoothstep(.99965,.99985,dot(ray,sun));
        float stars=step(.9988,hash(floor((frame*ray)*1100.)))*smoothstep(75.,160.,height);color+=stars*.7;
        return color;}
      void main(){
        vec3 ray=normalize(cameraBasis*vec3(screen.x*aspect*tanFov,screen.y*tanFov,-1.));
        vec3 center=vec3(0.,-R-height,0.);float distance=hitSphere(ray,0.);
        vec3 color=sky(ray);
        if(distance>0.){
          vec3 p=eye+ray*distance;vec3 n=normalize(p-center);vec3 globeNormal=normalize(frame*n);
          vec2 uv=vec2((atan(-globeNormal.z,globeNormal.x)+PI)/(2.*PI),asin(clamp(globeNormal.y,-1.,1.))/PI+.5);
          vec3 map=texture2D(day,uv).rgb;
          vec3 relative=p+launchOffset;
          vec2 ground=vec2(dot(relative,east),-dot(relative,north))*1000.;
          map=applyKennedy(map,ground,1.-smoothstep(24.,58.,height));
          color=map*(.28+.9*max(dot(n,sun),0.));
          float cloudShadow=smoothstep(.52,.69,fbm(globeNormal*650.+vec3(2.,1.,0.)));color*=1.-cloudShadow*.20;
          float haze=(1.-exp(-distance/(48.+height*4.)))*exp(-height/31.);
          color=mix(color,vec3(.38,.57,.73),haze*.78);
        }
        // A separate cloud shell makes clouds pass below the vehicle instead
        // of painting them into a stretched surface image.
        for (int index = 0; index < 2; index++) {
          int layer = height + eye.y > 7.5 ? 1 - index : index;
          float shell = layer == 0 ? 7.5 : 2.8;
          float cloudDistance = hitSphere(ray, shell);
          if (cloudDistance <= 0. || (distance > 0. && cloudDistance >= distance)) continue;
          vec3 cloudPoint = eye + ray * cloudDistance;
          vec3 n = normalize(cloudPoint - center);
          vec3 globeNormal = frame * n;
          float pattern = fbm(globeNormal * (layer == 0 ? 610. : 980.) + vec3(2., 1. + 14. * float(layer), 0.));
          float coverage = smoothstep(layer == 0 ? .48 : .55, .70, pattern);
          coverage *= .79 + .21 * noise(globeNormal * 2700.);
          float cloudFade = 1. - smoothstep(140., 510., cloudDistance);
          cloudFade *= smoothstep(.07, .50, abs(height + eye.y - shell));
          vec3 cloudColor = mix(vec3(.49, .59, .66), vec3(.95, .96, .92), smoothstep(.49, .73, pattern));
          cloudColor *= .65 + .35 * max(dot(n, sun), 0.);
          color = mix(color, cloudColor, coverage * cloudFade * .90);
        }
        float tangent=length(cross(eye-center,ray));
        float limb=(1.-smoothstep(R,R+25.,tangent))*step(R,tangent)*step(0.,-dot(eye-center,ray));
        color+=vec3(.08,.22,.42)*limb*smoothstep(12.,70.,height);
        float dip = sqrt(max(0., 2. * (height + eye.y) / R));
        float horizonHaze = (1. - smoothstep(0., .052, abs(ray.y + dip))) * exp(-height / 26.);
        color = mix(color, vec3(.48, .65, .77), .58 * horizonHaze);
        gl_FragColor=vec4(color,opacity);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const backdrop = new Mesh(new PlaneGeometry(2, 2), material);
  backdrop.frustumCulled = false;
  scene.add(backdrop);
  const launchPoint = launchUp.clone().multiplyScalar(EARTH_RADIUS);
  const north = new Vector3().crossVectors(launchUp, east).normalize();
  const basis = new Matrix4();
  return {
    scene,
    update(state, camera, rotation, sun, originHeightM, opacity) {
      camera.updateMatrixWorld();
      const worldToFlight = rotation.clone().invert();
      const origin = state.position.clone().addScaledVector(state.position.clone().normalize(), originHeightM * .001);
      const { uniforms } = material;
      uniforms.height.value = origin.length() - EARTH_RADIUS;
      uniforms.eye.value.copy(camera.position).multiplyScalar(.001);
      uniforms.cameraBasis.value.setFromMatrix4(camera.matrixWorld);
      uniforms.frame.value.setFromMatrix4(basis.makeRotationFromQuaternion(rotation));
      uniforms.launchOffset.value.copy(origin).sub(launchPoint).applyQuaternion(worldToFlight);
      uniforms.east.value.copy(east).applyQuaternion(worldToFlight);
      uniforms.north.value.copy(north).applyQuaternion(worldToFlight);
      uniforms.sun.value.copy(sun).applyQuaternion(worldToFlight);
      uniforms.aspect.value = camera.aspect;
      uniforms.tanFov.value = Math.tan(MathUtils.degToRad(camera.fov * .5));
      uniforms.opacity.value = opacity;
    },
  };
}
